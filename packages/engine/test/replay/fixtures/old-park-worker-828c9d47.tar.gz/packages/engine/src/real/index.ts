// 真端口的装配：库（packages/db）、GitHub（packages/github）、会话（packages/adapters 的插头，按执行方式分派：Claude Code、
// cursor-agent，real/hosts.ts）、工作树（fleet-agent-scope）各一份，拼成 EnginePorts。生产按环境变量装（realPortsFromEnv，
// 见 deploy/france/desired-config.json 的 engine 段，env 样例 #747 删了）；缺了哪一项就不起，讲清楚缺什么，不带着半套配置接活。

import { execFile } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import {
  bridgeMirasimConnector,
  type LedgerFs,
  type MeterFs,
  type MirasimConnect,
  parseSessionProxy,
  SCOPE_HELPER,
  SESSION_USERS,
  type SessionsFs,
  type SessionUser,
  StopReason,
  sessionProxyEnv,
  stopMirasimSession,
  switchSessionOrg,
} from '@fleet-dao/adapters';
import type { RunCommand } from '@fleet-dao/adapters/quota';
import {
  closeInterruptedScheduleRuns as closeInterruptedScheduleRunsInDb,
  countOpenRunsForIssue,
  createDb,
  type Db,
  findRepoProfile,
  finishScheduleRun,
  getFlowAssignment,
  getRun,
  issueWorkFacts,
  latestRunOfTask,
  listIntakeRepos,
  openSessionTrees,
  raiseLateReview,
  readEngineMasterRow,
  readFlowModeSettingRaw,
  recordCheckoutReceipt,
  recordFlowAssignment,
  recordPrHeadFiles,
  recordRouteProbeDone,
  recordRouteProbeStart,
  resolveAlertIfUnchangedSince,
  routeProbeAuditRows,
  scheduleHealth,
  startScheduleRun,
  taskTokenSpend,
  upsertAlert,
} from '@fleet-dao/db';
import { createGitHub } from '@fleet-dao/github';
import { intakeChatLimitsFrom, parseRepoProfile } from '@fleet-dao/shared';
import { errMessage } from '@fleet-dao/shared/util';
import { createPgStore, githubWhitelist, pgLedger, pgLocker } from '@fleet-dao/store';
import type { Client } from '@temporalio/client';
import type { EngineJobs, EngineTasks } from '../activities.ts';
import type { CheckoutBlockedAlert, CheckoutRecovered } from '../cold-verify-run.ts';
import type { EngineDrain } from '../drain.ts';
import { type DrainControlDeps, drainRequestFile, readDrainRequest } from '../drain-control.ts';
import { createEngineMasterGate, type EngineMasterGate } from '../engine-master.ts';
import { createDecideFlowMode } from '../flow-mode.ts';
import { probeAssignedRoute } from '../jobs/dispatch-probe.ts';
import type { WorkflowReader } from '../jobs/reconcile-common.ts';
import { probeOrgNow } from '../jobs/route-probe.ts';
import { routeProbeLock } from '../jobs/route-probe-now.ts';
import type { InterruptedScheduleClose } from '../jobs/timers.ts';
import { confirmManagedTreeIdle } from '../jobs/worktree-sweep.ts';
import { SESSION_MEMORY_HIGH_MB, SESSION_MEMORY_MAX_MB } from '../limits.ts';
import { type EnginePorts, PortError } from '../ports.ts';
import type { CarpoolRegistryView } from '../routing/index.ts';
import { toTaskSpendResult } from '../task-spend.ts';
import { configFromEnv } from '../worker.ts';
import { createNoteBare401 } from './bare-401.ts';
import { carpoolApiReader } from './carpool-api.ts';
import { carpoolRegistry } from './carpool-cap.ts';
import { carpoolWatchJob } from './carpool-watch.ts';
import { changelogJob } from './changelog.ts';
import { ciTimingsJob } from './ci-timings.ts';
import { cliUpgradeJob } from './cli-upgrade.ts';
import { cliVersionsJob } from './cli-versions.ts';
import { productionCpuUsage } from './cpu-usage.ts';
import { dailyBriefJob } from './daily-brief.ts';
import { drainNotifier } from './drain-alerts.ts';
import { e2eQuarantineJob } from './e2e-quarantine.ts';
import { describeFailure, scopeExec, type UserExec } from './exec.ts';
import { gitNetworkEnv } from './git-env.ts';
import { createGitHubPorts, type EngineGitHub } from './github-ports.ts';
import { githubReconcileJob } from './github-reconcile.ts';
import { groomJob } from './groom.ts';
import {
  cursorBareCommand,
  cursorLaunchCommand,
  DEFAULT_CURSOR_API_KEY_FILE,
  DEFAULT_CURSOR_VERSIONS_DIR,
  DEFAULT_GROK_BIN,
  grokLaunchCommand,
  hostDrivers,
} from './hosts.ts';
import {
  closedIssueEventsJob,
  type HourlyReconcileWiring,
  hourlyReconcileJob,
  temporalWorkflows,
  worktreeCleanupJob,
} from './hourly-reconcile.ts';
import { intakeJob } from './intake.ts';
import { intakeChatJob } from './intake-chat.ts';
import { issueGroomIdlePolicyFromEnv } from './issue-groom.ts';
import { issueKindJevFromEnv } from './issue-kind-jev.ts';
import { registerEngineJobs } from './jobs.ts';
import { judgeSelfCheckJob } from './judge-self-check.ts';
import { realMemoryAdmission } from './memory-admission.ts';
import { productionMemoryPeak } from './memory-peak.ts';
import { readMergeWaitChecks } from './merge-wait-checks.ts';
import { oneShotSessions } from './one-shot-sessions.ts';
import { NO_FUSION_SESSIONS, orgDriftReporter, orgSwitchRound } from './org-switch.ts';
import { orphanReaper } from './orphan-reap.ts';
import type { AssignedProber } from './pick-then-probe.ts';
import { type QuotaReadWiring, quotaReadJob } from './quota-read.ts';
import { realReleaseEvidence } from './release-evidence.ts';
import { requestSweepJob } from './request-sweep.ts';
import { retireEngineSchedules } from './retire-schedules.ts';
import type { ReviewAuditDeps } from './review-audit.ts';
import { routeProbeJob } from './route-probe.ts';
import {
  lazyTemporalWakeClient,
  routeWakerFromDb,
  wakeAfterProbeNow,
  wakeAfterProbeRound,
} from './route-wake.ts';
import { realChannelAttempts, realReservations, realRuns } from './runs-writer.ts';
import { createPlanSegmentResume, createSegmentSettled } from './segment-resume.ts';
import { reportSubagentDefs } from './segment-settings.ts';
import type { SegmentSpawnerDeps } from './segment-spawner.ts';
import { createSelfCheck } from './self-check.ts';
import { realCiTestCoverage } from './self-check-ci.ts';
import { DEFAULT_SESSION_IO_ROOT, type MirasimHandle, sessionHandoff } from './session-handoff.ts';
import { SESSION_ORG_TIMEOUT_MS, type SessionOrgReader, sessionOrgReader } from './session-org.ts';
import { createStorePorts } from './store-ports.ts';
import { lazyOnSuccess, prepareSubagents, readSubagentGuard, subagentsOnce } from './subagents-file.ts';
import { createTaskActivities } from './task-activities.ts';
import { createRunSegment } from './task-segment.ts';
import { createColdVerify, mirrorFileDiff, reviewChangesReader } from './task-verify.ts';
import { usageBackfillJob } from './usage-backfill.ts';
import { watchdogJob } from './watchdog.ts';
import { DEFAULT_WORK_ROOT, helperWorkTrees, type WorkTrees } from './worktrees.ts';

export interface RealPortsDeps extends ReviewAuditDeps {
  db: Db;
  gh: EngineGitHub;
  trees: WorkTrees;
  exec: UserExec;
  /**
   * 会话用户此刻挂的组织（real/session-org.ts）：选路只派它挂着的那个 Claude 订阅池。和探针、切号是同一个（按同一个起点判）。
   */
  sessionOrg: SessionOrgReader;
  /** 引擎自己的临时目录（bundle）、存档目录（没合并就收的树里没提交的改动）。 */
  tmpDir: string;
  archiveDir: string;
  /**
   * 删树前问任务和子任务工作流还在不在跑。不给就确认不了，不当成没人用。
   * 生产装配用 Temporal 的 state。
   */
  workflows?: Pick<WorkflowReader, 'state'>;
  /**
   * 排空（drain.ts）：在排空时选路回「过一会儿再选」。不给就不闸（测试、只起一次的工具）。
   * 三段会话登记进排空清单的是 oneShotSessions（下面 realPortsFromEnv），不在这里。
   */
  drain?: EngineDrain;
  /** 引擎总开关（engine-master.ts，#1086）：关着选路不派（回「过一会儿再选」）。不给就不闸（测试、只起一次的工具）。 */
  master?: EngineMasterGate;
  /**
   * 拼车并发登记的现核（real/carpool-cap.ts，#896）：选路前问，核对不上不往拼车池派。必填：不给就是拼车池不受登记核对管，
   * 漏接要过不了类型检查，不靠默认。
   */
  carpoolRegistry: () => Promise<CarpoolRegistryView>;
  /**
   * 动手会话收发目录的根（#2238，session-handoff.ts）：收孤儿时认放手标记，等人接回的不收。不给 = 不认（测试）。
   */
  sessionIoRoot?: string;
  /**
   * 放手的 Mirasim 会话过了时限没人接回时，给服务端发 stop（#2815，orphan-reap.ts）。不给 = 服务端的会话留着（测试）。
   */
  stopMirasim?: (handle: MirasimHandle) => Promise<{ confirmed: boolean; detail: string }>;
  /** 以下测试用。 */
  session?: Partial<{ helper: string; sudo: readonly string[]; gitBin: string; shBin: string }>;
  now?: () => Date;
  log?: (message: string, fields?: Record<string, unknown>) => void;
}

export interface RealPorts {
  ports: EnginePorts;
  /** 工人起来接活之前收上一轮留下的会话 scope、临时目录、没收场的 runs 行、预占的名额（real/orphan-reap.ts）；回收了几个 scope。 */
  reapOrphanSessions(): Promise<number>;
}

/** _tmp 归了 root 时，冷验收自己 mkdir 会 EACCES。经已放行的帮手把这一层改回引擎用户（不递归）。 */
function repairVerifyWorkTmp(): Promise<void> {
  return new Promise((resolve, reject) => {
    execFile('/usr/bin/sudo', ['-n', SCOPE_HELPER, 'ensure-tmp'], { timeout: 30_000 }, (error) => {
      if (error) reject(error);
      else resolve();
    });
  });
}

/** 这个目标的检出报警：再报原地更新（已撤的重开）——恢复后又坏是新故障，要看得见。 */
async function raiseCheckoutBlocked(db: Db, alert: CheckoutBlockedAlert): Promise<void> {
  await upsertAlert(db, {
    dedupeKey: alert.dedupeKey,
    level: alert.level,
    taskId: alert.taskId,
    title: alert.title,
    body: alert.body,
  });
}

/**
 * 这个目标真放进了完整检出：只撤它开跑之前报的那条（之后又报的是并发的新故障，回 changed 留着）。
 * 没撤成（库读写失败）抛给 placeVerifyCheckout 记日志，不当成已恢复。
 */
async function resolveCheckoutRecovered(db: Db, recovered: CheckoutRecovered): Promise<void> {
  await resolveAlertIfUnchangedSince(db, {
    dedupeKey: recovered.dedupeKey,
    by: 'cold-verify-checkout',
    since: recovered.startedAt,
  });
}

export function createRealPorts(deps: RealPortsDeps): RealPorts {
  const store = createStorePorts({
    db: deps.db,
    sessionOrg: deps.sessionOrg,
    carpoolRegistry: deps.carpoolRegistry,
    ...(deps.drain ? { drain: deps.drain } : {}),
    ...(deps.master ? { master: deps.master } : {}),
    ...(deps.now ? { now: deps.now } : {}),
    ...(deps.log ? { log: deps.log } : {}),
    // 派活时按内存做准入（#219）：读父节点 fleet-agents.slice 的 memory.current；本机开发没有这层就跳过（skip），不拦。
    memoryAdmission: realMemoryAdmission(),
  });
  const github = createGitHubPorts({
    gh: deps.gh,
    trees: deps.trees,
    exec: deps.exec,
    tmpDir: deps.tmpDir,
    archiveDir: deps.archiveDir,
    ...(deps.reviewChanges ? { reviewChanges: deps.reviewChanges } : {}),
    ...(deps.onLateReview ? { onLateReview: deps.onLateReview } : {}),
    ...(deps.now ? { now: deps.now } : {}),
    ...(deps.log ? { log: deps.log } : {}),
    ...(deps.session?.gitBin ? { gitBin: deps.session.gitBin } : {}),
    ...(deps.session?.shBin ? { shBin: deps.session.shBin } : {}),
    confirmTreeIdle: (dir, caller) =>
      confirmManagedTreeIdle({
        root: deps.trees.root,
        dir,
        openSessions: () => openSessionTrees(deps.db),
        ...(deps.workflows ? { workflows: deps.workflows } : {}),
        issue: (ref) => issueWorkFacts(deps.db, ref),
        ...(caller?.workflowId ? { exceptWorkflowId: caller.workflowId } : {}),
      }),
    // 推分支、开 PR 时记下这个头改了哪些文件（#3140）：任务页的改动卡读 pr_head_files
    recordHeadFiles: async (input) => {
      await recordPrHeadFiles(deps.db, { ...input, files: [...input.files] });
    },
  });
  const ports: EnginePorts = {
    pickRoute: store.pickRoute,
    raiseAlert: store.raiseAlert,
    recordTiming: store.recordTiming,
    saveTaskState: store.saveTaskState,
    recordRound: store.recordRound,
    acceptanceDuties: store.acceptanceDuties,
    createWorktree: github.createWorktree,
    removeWorktree: github.removeWorktree,
    pushBranch: github.pushBranch,
    openPr: github.openPr,
    updatePrBody: github.updatePrBody,
    waitCi: github.waitCi,
    syncMainline: github.syncMainline,
    closeIssue: github.closeIssue,
  };
  return {
    ports,
    reapOrphanSessions: orphanReaper({
      db: deps.db,
      trees: deps.trees,
      ...(deps.session?.helper ? { helper: deps.session.helper } : {}),
      ...(deps.session?.sudo ? { sudo: deps.session.sudo } : {}),
      ...(deps.sessionIoRoot ? { ioRoot: deps.sessionIoRoot } : {}),
      ...(deps.stopMirasim ? { stopMirasim: deps.stopMirasim } : {}),
      ...(deps.now ? { now: deps.now } : {}),
      ...(deps.log ? { log: deps.log } : {}),
    }),
  };
}

/** reclaude 装在会话用户自己家里（docs/ops.md 第五节）；{user} 换成会话用户。 */
export const DEFAULT_CLAUDE_BIN = '/home/{user}/.local/bin/reclaude';
export const DEFAULT_ENGINE_STATE_DIR = '/var/lib/fleet-dao/engine';
/**
 * 会话用户自己的 Mirasim 服务在他家里（{user} 换成会话用户；design 第十四节：单独起一份，不借旧系统那份）：
 * 令牌在 <这个目录>/.mirasim/run/local-<端口>.token，账本在 <这个目录>/.mirasim/traffic。端口不钉：装的时候由 Mirasim
 * 自己定，引擎每次连都现找（discoverMirasimEndpoint）。
 */
export const DEFAULT_MIRASIM_HOME = '/home/{user}';
/**
 * 桥接脚本（adapters 的 bridge.ts）：默认取和这份正在跑的引擎代码同一个检出里的那一份（和 worker.ts 的
 * DEFAULT_CLI_BIN_DIR 同一个道理——发布是整棵 monorepo 的检出，不是打包过的产物，packages/ 底下各仓还在原位）。
 * 会话用户读得到这份检出（405 那样的发布目录 755，第三节目录表），不用另外装一份。
 * 路径经 adapters 的 package.json exports 的子路径取（#901 ⑥：原来是 new URL('../../../adapters/src/…')，绕过 exports，
 * adapters 改目录结构会悄悄断；现在改了目录，exports 一行跟着改，真文件不在 test/real/mirasim-bridge-path.test.ts 当场红）。
 * 用 createRequire().resolve 而不是 import.meta.resolve：同步、在 vitest 和 node 里行为一样；都返回真实路径（不是 node_modules 里的符号链接）。
 */
export const DEFAULT_MIRASIM_BRIDGE_SCRIPT = createRequire(import.meta.url).resolve(
  '@fleet-dao/adapters/mirasim-bridge',
);
/** 会话读得到的 node（法国装机脚本、发布脚本到处这么写死，第五节）；桥接不用另外配置。 */
export const MIRASIM_BRIDGE_NODE = '/usr/bin/node';

export interface RealPortsConfig {
  machine: string;
  workRoot: string;
  stateDir: string;
  claudeBin: string;
  /** 会话用户家里 cursor-agent 的版本目录（{user} 换成会话用户）：每次起都在这下面现找 current → 最新版本。 */
  cursorVersionsDir: string;
  /** 会话用户家里的 grok（{user} 换成会话用户）：每次起都由会话用户先看它在不在。 */
  grokBin: string;
  /** 会话用户家里的 Mirasim 服务（{user} 换成会话用户）：每次连都现找端口、现读令牌。 */
  mirasimHome: string;
  /** 桥接脚本的绝对路径（会话用户读得到；real/index.ts 的 DEFAULT_MIRASIM_BRIDGE_SCRIPT）。 */
  mirasimBridge: string;
  /**
   * 会话出网经的代理（FLEET_SESSION_PROXY，规范成 http://主机:端口）：没写、空着是直连（法国）。
   * cursor-agent、grok 的会话带上，Claude 不带（hosts.ts）。
   */
  sessionProxy?: string;
}

/** 缺的、认不出的一律报错（一次列全），不带着半套配置接活。 */
export function realPortsConfigFromEnv(env: Readonly<Record<string, string | undefined>>): RealPortsConfig {
  const problems: string[] = [];
  const machine = env.FLEET_MACHINE_NAME?.trim() ?? '';
  if (!machine)
    problems.push('FLEET_MACHINE_NAME（这台机器给人看的名字，例如「法国」：要人重新登录时写清去哪台机器）');
  if (!env.DATABASE_URL?.trim()) problems.push('DATABASE_URL');
  const workRoot = env.FLEET_WORK_DIR?.trim() || DEFAULT_WORK_ROOT;
  if (!workRoot.startsWith('/')) problems.push(`FLEET_WORK_DIR 要写绝对路径（现在是 ${workRoot}）`);
  const stateDir = env.FLEET_ENGINE_STATE_DIR?.trim() || DEFAULT_ENGINE_STATE_DIR;
  if (!stateDir.startsWith('/')) problems.push(`FLEET_ENGINE_STATE_DIR 要写绝对路径（现在是 ${stateDir}）`);
  const claudeBin = env.FLEET_CLAUDE_BIN?.trim() || DEFAULT_CLAUDE_BIN;
  if (!claudeBin.startsWith('/')) problems.push(`FLEET_CLAUDE_BIN 要写绝对路径（现在是 ${claudeBin}）`);
  const cursorVersionsDir = env.FLEET_CURSOR_VERSIONS_DIR?.trim() || DEFAULT_CURSOR_VERSIONS_DIR;
  if (!cursorVersionsDir.startsWith('/')) {
    problems.push(`FLEET_CURSOR_VERSIONS_DIR 要写绝对路径（现在是 ${cursorVersionsDir}）`);
  }
  const grokBin = env.FLEET_GROK_BIN?.trim() || DEFAULT_GROK_BIN;
  if (!grokBin.startsWith('/')) problems.push(`FLEET_GROK_BIN 要写绝对路径（现在是 ${grokBin}）`);
  const mirasimHome = env.FLEET_MIRASIM_HOME?.trim() || DEFAULT_MIRASIM_HOME;
  if (!mirasimHome.startsWith('/')) problems.push(`FLEET_MIRASIM_HOME 要写绝对路径（现在是 ${mirasimHome}）`);
  // 默认值是 fileURLToPath 现算的（和 worker.ts 的 DEFAULT_CLI_BIN_DIR 同一个道理），在这台机器上本来就是绝对路径、
  // 只是开发机（Windows）上是 D:\... 这个样子——只有人手写了 FLEET_MIRASIM_BRIDGE 才照 POSIX 的绝对路径规矩查，
  // 默认值不查（法国是 Linux，真跑时这条本来就成立）。
  const rawMirasimBridge = env.FLEET_MIRASIM_BRIDGE?.trim();
  if (rawMirasimBridge && !rawMirasimBridge.startsWith('/')) {
    problems.push(`FLEET_MIRASIM_BRIDGE 要写绝对路径（现在是 ${rawMirasimBridge}）`);
  }
  const mirasimBridge = rawMirasimBridge || DEFAULT_MIRASIM_BRIDGE_SCRIPT;
  // 写了却认不出就不起：不悄悄当成直连（直连出不了网的机器上，会话会一个个莫名其妙地连不上）
  const rawProxy = env.FLEET_SESSION_PROXY?.trim();
  let sessionProxy: string | undefined;
  if (rawProxy) {
    try {
      sessionProxy = parseSessionProxy(rawProxy);
    } catch (err) {
      problems.push(`FLEET_SESSION_PROXY：${errMessage(err)}`);
    }
  }
  if (problems.length > 0) throw new Error(`真端口起不来，本机配置缺这些或不对：${problems.join('；')}`);
  return {
    machine,
    workRoot,
    stateDir,
    claudeBin,
    cursorVersionsDir,
    grokBin,
    mirasimHome,
    mirasimBridge,
    ...(sessionProxy === undefined ? {} : { sessionProxy }),
  };
}

/**
 * 起执行体的命令（绝对路径），会话和探针同一份：reclaude、cursor-agent、grok 都装在会话用户自己家里，{user} 换成会话用户。
 * cursor-agent 不钉版本：以会话用户的身份先读它家里的 API 密钥（DEFAULT_CURSOR_API_KEY_FILE，不做成配置），再在版本目录下
 * 现找 current → 最新版本（hosts.ts 的 cursorLaunchCommand）。grok 由会话用户先看在不在（grokLaunchCommand）。
 */
export function agentCommands(config: Pick<RealPortsConfig, 'claudeBin' | 'cursorVersionsDir' | 'grokBin'>): {
  claudeCommand(user: SessionUser): string[];
  cursorCommand(user: SessionUser): string[];
  grokCommand(user: SessionUser): string[];
} {
  return {
    claudeCommand: (user) => [config.claudeBin.replaceAll('{user}', user)],
    cursorCommand: (user) =>
      cursorLaunchCommand(
        config.cursorVersionsDir.replaceAll('{user}', user),
        DEFAULT_CURSOR_API_KEY_FILE.replaceAll('{user}', user),
      ),
    grokCommand: (user) => grokLaunchCommand(config.grokBin.replaceAll('{user}', user)),
  };
}

const MIRASIM_TOKEN_NAME = /^local-([1-9][0-9]{0,4})\.token$/;

/** 一条以那个会话用户的身份跑的短命令：起个短命 scope（scopeId 每次都不同，同一时刻不撞）。 */
function execAs(exec: UserExec, user: SessionUser, argv: string[], tag: string, timeoutMs = 10_000) {
  return exec({ user, cwd: '/', argv, timeoutMs, scopeId: `${tag}-${randomUUID()}` });
}

/** ls 报「没有这个路径」的样子（GNU coreutils：退出 2，stderr 里这句）；和别的读不了（权限、没查成）分开报。 */
function isMissingPath(r: { code: number | null; stderr: string }): boolean {
  return r.code === 2 && /No such file or directory/.test(r.stderr);
}

/**
 * 经 exec 以那个会话用户 cat 一个文件：值不上命令行、不进日志（只有路径在 argv 里；错误里只有路径和 cat 的 stderr，没有内容）。
 * 读不了抛错、不回空串；没有这个文件、没权限分别带 code ENOENT、EACCES（和 node:fs 一样，额度读取器按它写「读不到」的原因）。
 */
export async function catAsUser(
  exec: UserExec,
  user: SessionUser,
  path: string,
  tag = 'mirasim-cat',
): Promise<string> {
  const r = await execAs(exec, user, ['/bin/cat', '--', path], tag);
  if (r.code !== 0) {
    const err = new Error(describeFailure(`读 ${path}`, r)) as NodeJS.ErrnoException;
    if (/No such file or directory/.test(r.stderr)) err.code = 'ENOENT';
    else if (/Permission denied/.test(r.stderr)) err.code = 'EACCES';
    throw err;
  }
  return r.stdout.toString('utf8');
}

/**
 * 经 exec 以那个会话用户在几份文件里筛出含任一个 needle 的行（grep -h -F，按字面认，不当正则）：Mirasim 用量账本按月一份、几十 MB，
 * 不整份 cat 过来（#1935）。一行都没对上（grep 退出 1）回空串；读不了（退出 2、超时、起不来）抛错，错误里只有路径和 grep 的
 * stderr，没有内容。needle 只收 uuid 这类不带空白、不以 - 开头的串，免得被当成 grep 的参数。
 */
export async function grepAsUser(
  exec: UserExec,
  user: SessionUser,
  needles: readonly string[],
  paths: readonly string[],
  tag = 'mirasim-grep',
  timeoutMs = 10_000,
): Promise<string> {
  if (needles.length === 0 || paths.length === 0) return '';
  for (const n of needles) {
    if (!/^[0-9A-Za-z][0-9A-Za-z_:.-]*$/.test(n))
      throw new Error(`筛账本的关键字认不出：${JSON.stringify(n)}`);
  }
  const argv = ['/bin/grep', '-h', '-F', ...needles.flatMap((n) => ['-e', n]), '--', ...paths];
  const r = await execAs(exec, user, argv, tag, timeoutMs);
  if (r.code === 1) return '';
  if (r.code !== 0) throw new Error(describeFailure(`筛 ${paths.join('、')}`, r));
  return r.stdout.toString('utf8');
}

/**
 * 以会话用户的身份起一条命令（claude-usage 起 reclaude）。和账本、Mirasim 桥接同一条 exec：fleet-agent-scope 降权后再跑，
 * 引擎用户不直接 spawn 会话用户家里的二进制（那是 EACCES）。代理写上 /usr/bin/env 的参数，和读组织同一条（session-org.ts）；
 * 没登记代理就不加。通道自己没起来、代理认不出，收成 spawnError 交回读取器，由它写成「起不来」的原因，不抛成空读数。
 */
export function runCommandAsUser(exec: UserExec, user: SessionUser, proxy?: string): RunCommand {
  return async (argv, { cwd, signal }) => {
    let full = argv;
    if (proxy) {
      try {
        const envArgs = Object.entries(sessionProxyEnv(proxy)).map(([k, v]) => `${k}=${v}`);
        full = ['/usr/bin/env', ...envArgs, ...argv];
      } catch (e) {
        return {
          code: null,
          stdout: '',
          stderr: '',
          killed: false,
          spawnError: errMessage(e),
        };
      }
    }
    let r: Awaited<ReturnType<UserExec>>;
    try {
      r = await exec({
        user,
        cwd,
        argv: full,
        timeoutMs: SESSION_ORG_TIMEOUT_MS,
        scopeId: `quota-claude-${randomUUID().slice(0, 8)}`,
        ...(signal ? { signal } : {}),
      });
    } catch (e) {
      return { code: null, stdout: '', stderr: '', killed: false, spawnError: errMessage(e) };
    }
    return {
      code: r.code,
      stdout: r.stdout.toString('utf8'),
      stderr: r.stderr,
      killed: r.timedOut || r.aborted,
      ...(r.spawnError ? { spawnError: r.spawnError } : {}),
    };
  };
}

/**
 * 额度读取起 Claude Code 的工作目录：以会话用户建在它家里，每次核对是空的真目录。
 * 引擎自己家的那份（quotaWorkDir）会话用户进不去；在 /tmp 或它的家目录根上起，会把那里的项目设置和钩子一起加载。
 */
export async function quotaCwdAsUser(exec: UserExec, user: SessionUser, home: string): Promise<string> {
  const dir = `${home.replaceAll('{user}', user)}/.cache/fleet-dao/quota-cwd`;
  const made = await execAs(exec, user, ['/bin/mkdir', '-p', '--', dir], 'quota-cwd');
  if (made.code !== 0) throw new Error(describeFailure(`建额度读取目录 ${dir}`, made));
  const listed = await execAs(exec, user, ['/bin/ls', '-A', '--', dir], 'quota-cwd-ls');
  if (listed.code !== 0) throw new Error(describeFailure(`列额度读取目录 ${dir}`, listed));
  const entries = listed.stdout
    .toString('utf8')
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);
  if (entries.length) {
    throw new Error(`${dir} 不是空的（${entries.slice(0, 3).join('、')}），不在里面起 Claude Code`);
  }
  return dir;
}

/**
 * 额度读取里凭据或二进制在会话用户家里的读取器：引擎用户读不到、也起不来。
 * Cursor、Grok 经 exec 以会话用户读文件（#1195）；Mirasim 池经桥接以会话用户的身份连（#1284，和账本同一条路）；
 * claude-usage 经同一条 exec 起 reclaude（二进制在会话用户家里，引擎用户直接 spawn 是 EACCES）。
 */
export const QUOTA_USER_READERS = [
  'cursor-dashboard',
  'grok-billing',
  'mirasim-relay',
  'claude-usage',
] as const;

export function quotaAsUser(
  exec: UserExec,
  user: SessionUser,
  home: string,
  /** 给了就让 mirasim-relay 读取器经桥接连（mirasimDepsFor 的 connect）；不给它就仍读令牌文件、直连，在法国必然 EACCES。 */
  mirasim?: { connect(user: SessionUser): MirasimConnect },
  /** 会话出网的代理（法国直连不给）。claude-usage 起 reclaude 时写上，和读组织同一条。 */
  proxy?: string,
  /** 给了就让 Cursor 额度读取在登录令牌被拒或登录文件不在（ENOENT）时刷新一次（`cursor-agent status`，不放 API 密钥）；不给就没有刷新手段。 */
  cursorVersionsDir?: string,
  /**
   * 给了就让 Grok 额度读取在访问令牌过期、登录文件里还有 refresh_token 时，以会话用户跑一次 `grok models` 让 CLI 自己续。
   * 不给就没有续期手段，读取器报 auth_refreshable，不碰 refresh_token。
   */
  grokBin?: string,
): NonNullable<QuotaReadWiring['asUser']> {
  const runCommand = runCommandAsUser(exec, user, proxy);
  const homeDir = home.replaceAll('{user}', user);
  return {
    readers: QUOTA_USER_READERS,
    readFile: (path) => catAsUser(exec, user, path, 'quota-cat'),
    homeDir,
    runCommand,
    workDir: () => quotaCwdAsUser(exec, user, home),
    ...(mirasim ? { connectMirasim: mirasim.connect(user) } : {}),
    ...(cursorVersionsDir
      ? {
          refreshCursorLogin: (signal: AbortSignal) =>
            refreshCursorLogin(runCommand, cursorVersionsDir.replaceAll('{user}', user), signal),
        }
      : {}),
    ...(grokBin
      ? {
          refreshGrokLogin: (signal: AbortSignal) =>
            refreshGrokLogin(runCommand, grokBin.replaceAll('{user}', user), homeDir, signal),
        }
      : {}),
  };
}

/** 刷新 Cursor 登录令牌的命令最长跑多久：比读取器整体的 60 秒短，这样超时由这里报成「刷新命令超时」，不是读取器的笼统超时。 */
export const CURSOR_REFRESH_TIMEOUT_MS = 40_000;

/**
 * 让 grok CLI 自己续访问令牌的命令最长跑多久。比 grok 读取器的 60 秒短，超时由这里写明，不是笼统的「没读完」。
 * 取舍见 refreshGrokLogin：在读数过期（看门狗 30 分钟）前跑，而不是给看门狗加宽限。
 */
export const GROK_REFRESH_TIMEOUT_MS = 20_000;

/**
 * 以会话用户的身份跑一次 `cursor-agent status`（环境里没有 API 密钥）：cursor-agent 发现登录令牌过期、或登录文件刚被会话起停删掉，会自己刷新并重写登录文件。
 * 起不来、超时、非 0 退出都抛错并带原因（stderr/stdout 的头几行）；成功只代表命令跑完了，令牌换没换由读取器重读后再试来验。
 */
export async function refreshCursorLogin(
  run: RunCommand,
  versionsDir: string,
  signal: AbortSignal,
  timeoutMs = CURSOR_REFRESH_TIMEOUT_MS,
): Promise<void> {
  const own = new AbortController();
  const timer = setTimeout(
    () => own.abort(new StopReason('wall-clock', `刷新登录超过 ${Math.round(timeoutMs / 1000)} 秒`)),
    timeoutMs,
  );
  try {
    const r = await run(cursorBareCommand(versionsDir, ['status']), {
      cwd: '/',
      env: {},
      signal: AbortSignal.any([signal, own.signal]),
    });
    if (r.spawnError) throw new Error(`起不来：${r.spawnError}`);
    if (r.killed) {
      throw new Error(
        own.signal.aborted ? `超过 ${Math.round(timeoutMs / 1000)} 秒没跑完，被叫停` : '被叫停',
      );
    }
    if (r.code !== 0) {
      const said = (r.stderr.trim() || r.stdout.trim()).split('\n').slice(0, 3).join(' / ').slice(0, 300);
      throw new Error(`退出码 ${r.code}${said ? `：${said}` : ''}`);
    }
  } finally {
    clearTimeout(timer);
  }
}

/**
 * 以会话用户跑一次 `grok models`（只列模型就退出，不起会话、不花额度），让 CLI 自己续访问令牌并重写 auth.json。
 * 读取器不碰 refresh_token：自己续会轮换它，CLI 手里那份就作废。
 * 取舍：不改看门狗的 30 分钟。宽限只少报「没按期跑成」，读数仍旧，选路继续把主力 grok 按「额度没读成」排后面。
 * 所以在那条线之前（这一轮额度读取发现访问令牌过期时）由这里续。关了自动升级，免得列模型时半路换二进制。
 * 起不来、超时、非 0 退出都抛错并带原因；成功只代表命令跑完了，令牌换没换由读取器重读后再试来验。
 */
export async function refreshGrokLogin(
  run: RunCommand,
  bin: string,
  cwd: string,
  signal: AbortSignal,
  timeoutMs = GROK_REFRESH_TIMEOUT_MS,
): Promise<void> {
  const own = new AbortController();
  const timer = setTimeout(
    () => own.abort(new StopReason('wall-clock', `刷新登录超过 ${Math.round(timeoutMs / 1000)} 秒`)),
    timeoutMs,
  );
  try {
    const r = await run(['/usr/bin/env', 'GROK_DISABLE_AUTOUPDATER=1', ...grokLaunchCommand(bin), 'models'], {
      cwd,
      env: {},
      signal: AbortSignal.any([signal, own.signal]),
    });
    if (r.spawnError) throw new Error(`起不来：${r.spawnError}`);
    if (r.killed) {
      throw new Error(
        own.signal.aborted ? `超过 ${Math.round(timeoutMs / 1000)} 秒没跑完，被叫停` : '被叫停',
      );
    }
    if (r.code !== 0) {
      const said = (r.stderr.trim() || r.stdout.trim()).split('\n').slice(0, 3).join(' / ').slice(0, 300);
      throw new Error(`退出码 ${r.code}${said ? `：${said}` : ''}`);
    }
  } finally {
    clearTimeout(timer);
  }
}

/**
 * 这个执行体目录下，record.json 修改时间不早于 sinceMs 的会话目录名（MS-18 的预筛）。
 * 一次 find，不逐份 cat：法国一个执行体下有几百条历史，逐份去读要几十秒，对账会拖过时间窗。
 * find 的 -newermt 是「严格新于」，阈值再早 1 秒，卡在同一秒上的不漏；进不进窗仍由档案里的 createdAt 定。
 * 目录不在抛 code 为 ENOENT 的错（和 ls 一样）。有别的错（权限、超时）照抛，调用方当成读不了，不当成没有。
 */
export async function recentMirasimSessionIds(
  exec: UserExec,
  user: SessionUser,
  dir: string,
  sinceMs: number,
): Promise<string[]> {
  const sec = Math.floor(sinceMs / 1000) - 1;
  const r = await execAs(
    exec,
    user,
    [
      '/usr/bin/find',
      dir,
      '-mindepth',
      '2',
      '-maxdepth',
      '2',
      '-name',
      'record.json',
      '-newermt',
      `@${sec}`,
      '-printf',
      '%h\n',
    ],
    'mirasim-sessions-find',
    20_000,
  );
  if (r.code !== 0) {
    const err = new Error(describeFailure(`列 ${dir} 里最近的会话`, r)) as NodeJS.ErrnoException;
    if (r.stdout.length === 0 && /No such file or directory/.test(r.stderr)) err.code = 'ENOENT';
    throw err;
  }
  const ids: string[] = [];
  for (const line of r.stdout.toString('utf8').split('\n')) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const slash = trimmed.lastIndexOf('/');
    ids.push(slash >= 0 ? trimmed.slice(slash + 1) : trimmed);
  }
  return ids;
}

/** 经 exec 以那个会话用户列一个目录：LedgerFs 的 readdir 要的形状（没有这个目录时抛 code 为 ENOENT 的错，和 node:fs 一样）。 */
async function lsAsUser(exec: UserExec, user: SessionUser, dir: string): Promise<string[]> {
  const r = await execAs(exec, user, ['/bin/ls', '-1', '--', dir], 'mirasim-ls');
  if (isMissingPath(r)) {
    const err = new Error(`没有这个目录：${dir}`) as NodeJS.ErrnoException;
    err.code = 'ENOENT';
    throw err;
  }
  if (r.code !== 0) throw new Error(describeFailure(`列 ${dir}`, r));
  return r.stdout
    .toString('utf8')
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);
}

/**
 * 这个会话用户自己的 Mirasim 服务在哪（design 第十四节：给他单独起一份，不借旧系统那份）：列他家里的
 * <home>/.mirasim/run，只认「恰好一份 local-<端口>.token」——一份都没有就是这个会话用户还没配好，不止一份就是认不出
 * 该用哪份（只该有一份 Mirasim 服务）。令牌本身不在这里读（每次建连都现读，不缓存：桥接自己以会话用户的身份读，
 * bridge.ts），这里只定端口和令牌文件的位置——这一步是 ls 一个目录，不是连端口，不受回环口防火墙限制。
 */
export async function discoverMirasimEndpoint(
  exec: UserExec,
  user: SessionUser,
  home: string,
): Promise<{ port: number; tokenFile: string }> {
  const dir = `${home}/.mirasim/run`;
  let names: string[];
  try {
    names = (await lsAsUser(exec, user, dir)).filter((n) => MIRASIM_TOKEN_NAME.test(n));
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'ENOENT') {
      throw new Error(
        `${user} 家里没有 ${dir}：这个会话用户还没单独起一份 Mirasim 服务（docs/ops.md 第五节「会话用户的 Mirasim」；配好之前 Mirasim 路由保持关闭，design 第十四节）`,
      );
    }
    throw err;
  }
  if (names.length === 0) {
    throw new Error(
      `${dir} 下没有 local-<端口>.token：这个会话用户还没单独起一份 Mirasim 服务（docs/ops.md 第五节「会话用户的 Mirasim」）`,
    );
  }
  if (names.length > 1) {
    throw new Error(
      `${dir} 下有 ${names.length} 份令牌（${names.join('、')}）：认不出该用哪一份，只该有一份 Mirasim 服务`,
    );
  }
  const name = names[0] as string;
  const port = Number(MIRASIM_TOKEN_NAME.exec(name)?.[1]);
  if (!Number.isInteger(port)) throw new Error(`令牌文件名认不出：${name}（该是 local-<端口>.token）`);
  return { port, tokenFile: `${dir}/${name}` };
}

export interface MirasimBridgeConfig {
  /** node 加桥接脚本的绝对路径（bridge-connect.ts 的 bridgeCommand）。 */
  command: readonly string[];
  /** 以下测试用：换假帮手、假 spawn。 */
  helper?: string;
  sudo?: readonly string[];
  spawn?: Parameters<typeof bridgeMirasimConnector>[1]['spawn'];
}

/**
 * 会话用户自己的 Mirasim 服务：账本目录、读账本用的（as-user）文件访问经 exec 以那个会话用户读（引擎自己的进程，
 * fleet 用户，进不去他的家，750，design 第十四节）；连接（connect）经桥接（bridge.ts）以那个会话用户的身份跑，不再由
 * 引擎的进程直连回环口——法国防火墙只放行会话用户和 root 连那个口（docs/ops.md 第五节「会话用户的口只许它自己连」，
 * #35），实测引擎（fleet 用户）连不上，是这条路由派不出去的断链（#345 后续）。discoverMirasimEndpoint
 * 现找端口（exec 以会话用户 ls，不走网络，不碰防火墙）；令牌桥接自己以会话用户的身份现读，不经引擎传值。
 */
export function mirasimDepsFor(
  exec: UserExec,
  home: string,
  bridge: MirasimBridgeConfig,
): {
  connect(user: SessionUser): MirasimConnect;
  ledgerDir(user: SessionUser): string;
  ledgerFs(user: SessionUser): LedgerFs;
  /** 这个会话用户的会话档案（~/.mirasim/sessions）：没等到 accepted 时按工作目录和起针时间对账（MS-18）。 */
  sessionsDir(user: SessionUser): string;
  /** 以他的身份读会话档案。recentSessionIds 一次找出窗内改过的，不逐份 cat 历史。 */
  sessionsFs(user: SessionUser): SessionsFs;
  /** 这个会话用户的 Mirasim 用量账本目录（~/.mirasim/insights，中转计量回填在这里，#1935）。 */
  meterDir(user: SessionUser): string;
  /** 以他的身份读用量账本：ls、grep -F 都经 exec。 */
  meterFs(user: SessionUser): MeterFs;
} {
  const homeOf = (user: SessionUser) => home.replaceAll('{user}', user);
  return {
    connect: (user) => async () => {
      const at = homeOf(user);
      const { port, tokenFile } = await discoverMirasimEndpoint(exec, user, at);
      return bridgeMirasimConnector(
        { user, port, tokenFile },
        {
          bridgeCommand: bridge.command,
          ...(bridge.helper ? { helper: bridge.helper } : {}),
          ...(bridge.sudo ? { sudo: bridge.sudo } : {}),
          ...(bridge.spawn ? { spawn: bridge.spawn } : {}),
        },
      )();
    },
    ledgerDir: (user) => `${homeOf(user)}/.mirasim/traffic`,
    ledgerFs: (user) => ({
      readdir: (dir) => lsAsUser(exec, user, dir),
      readFile: (path) => catAsUser(exec, user, path),
    }),
    sessionsDir: (user) => `${homeOf(user)}/.mirasim/sessions`,
    sessionsFs: (user) => ({
      readdir: (dir) => lsAsUser(exec, user, dir),
      readFile: (path) => catAsUser(exec, user, path),
      recentSessionIds: (dir, sinceMs) => recentMirasimSessionIds(exec, user, dir, sinceMs),
    }),
    meterDir: (user) => `${homeOf(user)}/.mirasim/insights`,
    meterFs: (user) => ({
      readdir: (dir) => lsAsUser(exec, user, dir),
      linesWith: (needles, paths) => grepAsUser(exec, user, needles, paths),
    }),
  };
}

/**
 * 生产：按环境变量装真端口，连同定时任务要的东西（jobs）和起来时的登记（registerJobs：定时任务、判断题）。
 * 返回的 close 在工人停下后关库连接。
 */
export function realPortsFromEnv(
  env: Readonly<Record<string, string | undefined>> = process.env,
  extra: { drain?: EngineDrain; ownSha?: string | null; releasesDir?: string } = {},
): RealPorts & {
  jobs: EngineJobs;
  /** 任务工作流（#632）的真活动：不碰会话的五个、动手会话、冷验收会话。 */
  tasks: EngineTasks;
  registerJobs(): Promise<void>;
  /** 引擎起来、定时器起之前跑一遍：把退役名单（jobs/retired-schedules.ts）里 Temporal 上还在的删掉，见 real/retire-schedules.ts。 */
  retireSchedules(client: Pick<Client, 'schedule'>): Promise<void>;
  /** 每个定时任务最近一轮是几点起的（schedule_runs）；一轮都没有的不在里面。进程内定时器起来时补最近一轮要看（jobs/timers.ts）。 */
  jobLastStartedAt(): Promise<ReadonlyMap<string, Date>>;
  /** 引擎总开关的闸（#1086）：worker 起来先 refresh 一次、再 start 周期刷新；定时器入口、选路、一次性会话登记读它。 */
  master: EngineMasterGate;
  /** 总开关关着、这个定时任务这一轮被跳过：记一条 partial 进 schedule_runs（看门狗不当成「停了」，定时任务页看得到原因）。 */
  recordSkippedRun(jobId: string, why: string): Promise<void>;
  /** 定时器起之前：超过一轮工作上限还没结束的 schedule_runs 补记成 failed（#1522）。写库失败照抛。 */
  closeInterruptedScheduleRuns: InterruptedScheduleClose;
  close(): Promise<void>;
  stateDir: string;
  /** 排空要的几样（drain-control.ts）：读发布脚本的排空请求、查发布锁、到点停会话、报提醒。 */
  drainControl: Omit<DrainControlDeps, 'drain' | 'log'>;
  /** 引擎要走了（停机信号）：脱开跑的动手会话放手、不停（#2238），返回放手了哪几个。 */
  releaseSessions(why: string): string[];
} {
  const config = realPortsConfigFromEnv(env);
  const { db, close } = createDb({ env: env as Record<string, string | undefined> });
  // 引擎自己的 git（抓主线、推分支）也经这一档登记的代理出网：直连 github.com 不通时（Connection reset，
  // 动手前建工作树就卡在抓主线上，#786 同一个根）；git 认 http(s)_proxy 环境变量，gitEnv 照搬父环境里除凭据外的变量。
  // 只给 git 这一份环境，引擎进程自己的环境和起会话的环境（只从白名单抄）都不动；法国不登记代理、环境原样。
  const gh = createGitHub({
    ledger: pgLedger(db),
    locker: pgLocker(db),
    env: gitNetworkEnv(env as Record<string, string | undefined>, config.sessionProxy),
  });
  const trees = helperWorkTrees({ root: config.workRoot });
  const { claudeCommand, cursorCommand, grokCommand } = agentCommands(config);
  // 单子归类（#448）问的是判断题配置（issue-kind），走 issue-kind-jev.ts；起来时在 registerJobs 里登记。
  // 错误分流、停滞预判没有工作流再问，引擎不再登记、不再问。
  const issueKindJev = issueKindJevFromEnv(db, env);
  const exec = scopeExec();
  // Mirasim：会话（sessions.ts）和路由探针（route-probe.ts）共用同一份「怎么连、怎么读账本」；连接经桥接以会话用户的
  // 身份跑（法国防火墙只放行它自己和 root 连回环口），账本经这个 exec 以会话用户读（引擎自己的进程进不去他的家）
  const mirasim = mirasimDepsFor(exec, config.mirasimHome, {
    command: [MIRASIM_BRIDGE_NODE, config.mirasimBridge],
  });
  // 会话用户此刻挂的组织：法国只有一个会话用户（design 第九节），两个 Claude 池都跑在它下面、同一时刻只有它挂着的那个能派。
  // 以它跑它家里的 reclaude org list（和会话同一份 reclaude）；选路、探针、切号、每小时对账共用这一个（读成了的留 30 秒），
  // 按同一个起点判：读数变了、引擎没切过号，推 session-org:drift（带前后两次读数），定下来之前谁都不照它来（#335）
  const [sessionUser] = SESSION_USERS;
  const sessionOrg = sessionOrgReader({
    exec,
    user: sessionUser,
    reclaude: claudeCommand(sessionUser),
    proxy: config.sessionProxy,
    onEvent: orgDriftReporter({ db, user: sessionUser, machine: config.machine }),
  });
  // 拼车并发登记的核对（#194 方案 4.7、#896）：引擎起来核一遍推提醒（registerJobs），选路前、每小时对账判阶段派不派得出去时现核，
  // 对不上拼车池不派新活。同一个对象，「上一次对上没对上」的记忆只有一份。
  const carpoolCap = carpoolRegistry({ db, env, machine: config.machine });
  // 引擎总开关（#1086）：选路、一次性会话登记、定时器入口三处读同一个闸；起来时 worker 先刷新一次再起周期刷新。读不到按关。
  const master = createEngineMasterGate({
    read: () => readEngineMasterRow(db),
    log: (message) => console.info(message),
  });
  // 动手会话脱开引擎跑（#2238）：发版重启引擎时放手、新引擎接回，不再停在跑的会话
  const handoff = sessionHandoff(DEFAULT_SESSION_IO_ROOT);
  const taskLog = (message: string, fields?: Record<string, unknown>) => console.info(message, fields ?? {});
  // 冷验收、合前及每个已合并出口（含waitCi）共用真实reader和未送达明账；成员白名单每次现读。
  const members = createPgStore(db);
  const reviewChanges = reviewChangesReader({
    listReviews: (repo, prNumber) => gh.claims.listReviews(repo, prNumber),
    listReviewComments: (repo, prNumber, reviewId) => gh.claims.listReviewComments(repo, prNumber, reviewId),
    whitelist: async () => githubWhitelist(await members.listUsers()),
  });
  const reviewAudit: ReviewAuditDeps = {
    reviewChanges,
    onLateReview: async (note) => {
      await raiseLateReview(db, {
        repo: `${note.repo.owner}/${note.repo.name}`,
        prNumber: note.prNumber,
        source: 'merge-audit',
        review: note.review
          ? { reviewId: note.review.reviewId, reviewer: note.review.reviewer, commitId: note.review.commitId }
          : null,
        error: note.error,
        workflowId: note.workflowId,
      });
    },
  };
  // 删树前要问工作流还在不在跑。第一次用到才连 Temporal，和下面叫醒等路由共用这一条连接。
  const temporal = configFromEnv(env as Record<string, string | undefined>);
  const wakeClient = lazyTemporalWakeClient({ address: temporal.address, namespace: temporal.namespace });
  const real = createRealPorts({
    db,
    master,
    ...reviewAudit,
    carpoolRegistry: () => carpoolCap.view(),
    gh,
    trees,
    exec,
    sessionOrg,
    sessionIoRoot: handoff.root,
    // 放手的 Mirasim 会话过了时限没人接回：经桥接以会话用户的身份连服务端发 stop（法国只有一个会话用户）
    stopMirasim: (handle) => stopMirasimSession(mirasim.connect(SESSION_USERS[0]), handle.sessionKey),
    tmpDir: join(config.stateDir, 'tmp'),
    archiveDir: join(config.stateDir, 'archive'),
    ...(extra.drain ? { drain: extra.drain } : {}),
    workflows: {
      state: (id) => wakeClient.use((client) => temporalWorkflows(client).state(id)),
    },
  });
  // 三段的一次性会话（动手、验收）的登记：切号照它停下跑在 Claude 池上的那一段，切完任务工作流在原分支上重跑（#59）
  // 同时登记进发布排空的在途清单（#957）：不接 drain，发布排空看不见动手、验收会话，会提前放行、到点也停不到它们
  // （test/real/one-shot-drain.test.ts 钉着这一行和下面 stopSessions 里的 oneShots.drainStop）
  // 同时接引擎总开关：关着这一段不起会话（#1086，test/real/one-shot-sessions.test.ts 的「生产装配漏接引擎总开关」钉着这一行）
  const oneShots = oneShotSessions({ ...(extra.drain ? { drain: extra.drain } : {}), master });
  // 拼车用满切独享、恢复了切回（#157）：路由探针每一轮探之前判，经 root 帮手的 org-use 切；手上跑在 Claude 池上的会话
  // 先停下、切完接着干（#59：一次性会话在原分支上重跑这一段，Fusion 的会话换了池 fork 续上），不等它们跑完
  // #194：被拒当场判、定时盯读接口那一轮也走它（同一把单飞锁）；读接口给切号前现读，切完当场探切过去的池（和路由探针同一份探法）
  const readCarpoolApi = carpoolApiReader();
  // 叫醒等路由的活（real/route-wake.ts）：第一次叫醒时才连 Temporal（切号这条路上手里没有 Temporal 客户端）
  const routeWake = routeWakerFromDb(db, wakeClient, (level, text, fields) =>
    console[level === 'info' ? 'info' : level](text, fields ?? {}),
  );
  const orgSwitch = orgSwitchRound({
    db,
    org: sessionOrg,
    user: sessionUser,
    switchOrg: (to) => switchSessionOrg({ to, user: sessionUser }),
    sessions: NO_FUSION_SESSIONS,
    oneShots,
    machine: config.machine,
    readApi: readCarpoolApi,
    // 切完探通，当场叫醒等路由的任务工作流重新选一次（#194 方案 4.3，不等这一轮睡满），见 real/route-wake.ts
    probeNow: wakeAfterProbeNow((to) => probeOrgNow(routeProbe(), to), routeWake),
  });
  const routeProbe = routeProbeJob({
    db,
    trees,
    claudeCommand,
    cursorCommand,
    grokCommand,
    mirasimConnect: mirasim.connect,
    mirasimLedgerDir: mirasim.ledgerDir,
    mirasimLedgerFs: mirasim.ledgerFs,
    mirasimSessionsDir: mirasim.sessionsDir,
    mirasimSessionsFs: mirasim.sessionsFs,
    sessionOrg,
    // 探针那一轮里切的号：这一轮探完核对之后也叫醒（当场触发的那条路在上面 probeNow 里叫过了，两条路不重叠）
    orgSwitch: wakeAfterProbeRound(orgSwitch, routeWake),
    // 别的组织窗口重置、这一轮没探到：空闲时切过去发一条最小请求再切回（#49）。切号就是这一份帮手。
    kickOrg: {
      control: sessionOrg,
      switchTo: (to) => switchSessionOrg({ to, user: sessionUser }),
    },
    machine: config.machine,
    ...(config.sessionProxy === undefined ? {} : { sessionProxy: config.sessionProxy }),
  });
  // 额度读取和模型名册共用这一份会话用户身份：二进制和 Mirasim 口都在它家里。
  const quotaUser = quotaAsUser(
    exec,
    sessionUser,
    config.mirasimHome,
    mirasim,
    config.sessionProxy,
    config.cursorVersionsDir,
    config.grokBin,
  );
  // 每小时对账和一键清理工作树共用的装配（#1993）：同一个工作树管家、同一个会话用户执行器、同一份判据
  const reconcileWiring: HourlyReconcileWiring = {
    db,
    gh,
    trees,
    exec,
    archiveDir: join(config.stateDir, 'archive'),
    sessionOrg,
    carpoolRegistry: () => carpoolCap.view(),
    machine: config.machine,
    selfCheck: (repos) => gh.selfCheck(repos),
  };
  const jobs: EngineJobs = {
    githubReconcile: githubReconcileJob({
      db,
      gh,
      askIssueKind: issueKindJev.askKind,
      issueGroomIdlePolicy: issueGroomIdlePolicyFromEnv(env),
    }),
    // 路由探针和干活的会话用同一份执行体（reclaude、cursor-agent、grok、Mirasim）、同一个工作树的根（探针目录在它下面）
    routeProbe,
    // 驾驶舱的立即探测：和定时那一轮同一份探法、同一把锁，接手、探完各记一条操作记录
    routeProbeNow: () => ({
      rows: (since) => routeProbeAuditRows(db, since),
      start: (requestId, at) => recordRouteProbeStart(db, requestId, at),
      done: (input) => recordRouteProbeDone(db, input),
      probe: routeProbe,
      lock: routeProbeLock,
      now: () => new Date(),
      log: (level, text, fields) => console[level === 'info' ? 'info' : level](text, fields ?? {}),
    }),
    // 定时读额度（#76）：读成的写 quota_windows，读不到按规矩报警。
    // Cursor、Grok 的登录文件、Mirasim 的桥接、独享组织的 reclaude 都在会话用户那边：经 quotaAsUser 以它的身份读、起。
    // 同一轮里顺手读四个渠道的模型名册（#1302，六小时一次）：命令是各家执行体的前缀，读取器自己加 models。
    quotaRead: quotaReadJob({
      db,
      asUser: quotaUser,
      ...(quotaUser.runCommand
        ? {
            modelRoster: {
              commands: {
                cursor: cursorCommand(sessionUser),
                grok: grokCommand(sessionUser),
              },
              runCommand: quotaUser.runCommand,
              ...(quotaUser.workDir ? { workDir: quotaUser.workDir } : {}),
              ...(quotaUser.connectMirasim ? { connectMirasim: quotaUser.connectMirasim } : {}),
            },
          }
        : {}),
    }),
    // 拼车额度盯读（#194）：每分钟起一条，按情况读开放接口、交给切号当场判
    carpoolWatch: carpoolWatchJob({
      db,
      user: sessionUser,
      sessionOrg,
      orgSwitch,
      readApi: readCarpoolApi,
    }),
    // 每小时对账：同一个工作树管家（删树经 fleet-agent-scope）、同一个会话用户执行器（看树里还剩什么）；引擎这份 GitHub
    // （同一套 App 凭据）审合了的 PR、给排队的单补拉时现读挂在哪个版本、做两个机器人的权限自检
    hourlyReconcile: hourlyReconcileJob(reconcileWiring),
    // 一键清理没用的工作树（#1993）：和每小时对账同一份装配、同一个判据
    worktreeCleanup: worktreeCleanupJob(reconcileWiring),
    closedIssueEvents: closedIssueEventsJob(reconcileWiring),
    // 看门狗（#203）：按登记表看上面这些（和备份那几个）新不新鲜，没跑成、停了推提醒，恢复了自己撤；
    // 另看各项目主线多久没合 PR（决定 0093，jobs/merge-stall.ts），有待做的单还 N 小时没合就报，合了或没活了自己撤
    // 点名和读回不一致的旧挂起和叫醒等路由共用这一条 Temporal 连接（没这种挂起时不去连）
    watchdog: watchdogJob({ db, temporal: wakeClient }),
    // 拉单（#632）：每 5 分钟读开着「让 AI 接活」的仓里该做的单、起任务工作流；开关全关时是正常的空闲。
    intake: intakeJob({ db, gh }),
    // 判断题自检（#1365）：最近一次调用失败超过 30 分钟，发一道不占额度的固定题。不看总开关。
    judgeSelfCheck: judgeSelfCheckJob({ db, env }),
    // 每周刷新 CI 测试耗时表（#921）：读本仓 ci.yml 日志、重写表、开 PR。不看总开关。
    ciTimings: ciTimingsJob({ db, github: gh }),
    changelog: changelogJob({
      db,
      github: gh,
      ...(extra.releasesDir === undefined ? {} : { releasesDir: extra.releasesDir }),
    }),
    // 用量补记（#1935）：经 Mirasim 起的会话，以会话用户读他家里的用量账本（中转计量回填），把 runs 的输入、缓存、花费补齐。不看总开关。
    usageBackfill: usageBackfillJob({
      db,
      user: sessionUser,
      meterDir: mirasim.meterDir,
      trafficDir: mirasim.ledgerDir,
      meterFs: mirasim.meterFs,
    }),
    // 命令行工具版本（#1969）：probe 读在用版本，引擎进程拉官方最新。不升级。
    cliVersions: cliVersionsJob({ db }),
    // 需求整理（#2049）：删了满 30 天的需求连消息硬删并写操作记录，已结案的按规矩自动归档。不看总开关。
    requestSweep: requestSweepJob({ db }),
    // 每日简报（决定 0096）：读发布历史、库、GitHub，写一行提醒（后端推飞书）、用引擎机器人在 #1055 发评论。不看总开关。
    dailyBrief: dailyBriefJob({ db, gh }),
    // 隔离集进出（决定 0093）：偶发单改 quarantine.json，连续 7 天全过的移出并关单。不看总开关、不调模型。
    e2eQuarantine: e2eQuarantineJob({ db, github: gh }),
    // 命令行工具升级（#1971）：空闲时排空、写请求。引擎没有 root，不在这里装。不看总开关。
    cliUpgrade: cliUpgradeJob({
      db,
      ...(extra.drain ? { drain: extra.drain } : {}),
      master,
      env,
    }),
  };
  // 子代理（#1641，决定 0087）：claude-code 的干活会话带的 --agents 文件，引擎起来时从发布目录的 agents/subagents/ 生成一次；生成不成时
  // claude-code 的干活会话起不来（hosts.ts 写清原因），这里先记一条日志。Mirasim 的会话靠工作树里的 settings.local.json 挡子代理，
  // 要的是名字清单，现读现用（读不到就不起会话，不带着没挡的状态起）。
  const subagents = subagentsOnce(prepareSubagents, (error) =>
    taskLog('子代理定义文件生成不成', { error: error.message }),
  );
  const subagentGuard = lazyOnSuccess(readSubagentGuard);
  const taskRuns = realRuns({ db });
  // 动手会话（#632 S2-4b-2）和冷验收会话（S2-5b）：和 Fusion 的会话用同一份执行方式驱动，但自己一份（驱动没有状态，只是包着各家的
  // run 函数）；内存准入、会话的资源上限、runs 记账都用生产的那份，两种会话共用同一个 Spawner 装配。
  const segmentSpawner: SegmentSpawnerDeps = {
    db,
    runs: taskRuns,
    handoff,
    drivers: hostDrivers({
      claudeCommand,
      cursorCommand,
      grokCommand,
      mirasimConnect: mirasim.connect,
      mirasimLedgerDir: mirasim.ledgerDir,
      mirasimLedgerFs: mirasim.ledgerFs,
      mirasimSessionsDir: mirasim.sessionsDir,
      mirasimSessionsFs: mirasim.sessionsFs,
      sessionProxy: config.sessionProxy,
      agentsFile: async () => (await subagents()).file,
    }),
    trees,
    baseEnv: env,
    resources: { memoryHighMb: SESSION_MEMORY_HIGH_MB, memoryMaxMb: SESSION_MEMORY_MAX_MB, swapMaxMb: 0 },
    // 会话 scope 的内存峰值写进 runs（#948）：边跑边读 cgroup 的 memory.peak
    memoryPeak: productionMemoryPeak(),
    // 会话用掉的 CPU 秒数写进 runs（#1980）：边跑边读 cpu.stat，收场再读一次 usage_usec
    cpuUsage: productionCpuUsage(),
    // 拼车池上的会话被拒：证据当场交给切号判（#194 方案 4.3），不等路由探针那一轮；不等结果（切号要等这个会话收场）
    onCarpoolRejection: (rejection) => {
      void orgSwitch.now({ by: '拼车会话被拒', rejection });
    },
    log: taskLog,
  };
  // 选路给三段的一段预占的池的名额（#757）：开跑那一行（taskRuns.start）换掉，没开跑就收场的由这两个活动放掉
  const reservations = realReservations({ db });
  // 派前探测不通时工作流放掉这次预占（#1409）：没进 runSegment，不能占到过期
  jobs.releaseReservation = (reservationId) => reservations.release(reservationId);
  // 派前探测（#1798 片 4）：验收和整理选到一条就派前探一次，和动手那一段同一套（同一把锁，不让同一条路由同时起两个会话）；
  // cursor、grok、mirasim 不再被 kept 放行，15 分钟新鲜线一律真探。
  const probeAssigned: AssignedProber = (input) => probeAssignedRoute(routeProbe(), routeProbeLock, input);
  const runsDir = join(config.stateDir, 'runs');
  const tasks: EngineTasks = {
    ...createTaskActivities({
      openRunsForIssue: (repo, issue, workflowId) => countOpenRunsForIssue(db, repo, issue, workflowId),
      gh,
      trees,
      exec,
      log: taskLog,
      ...reviewAudit,
      profileOf: async (repo) => {
        const row = await findRepoProfile(db, repo.owner, repo.name);
        if (!row) throw new Error(`没有受管仓 ${repo.owner}/${repo.name}，读不了仓档案`);
        return row.profile;
      },
      readChecks: async (repo, head, signal) => {
        const row = await findRepoProfile(db, repo.owner, repo.name);
        if (!row) throw new Error(`没有受管仓 ${repo.owner}/${repo.name}，不知道合并要等哪些检查`);
        return readMergeWaitChecks(gh, repo, head, parseRepoProfile(row.profile).mergeSignals, signal);
      },
    }),
    async readCiPolicy(input) {
      if (input?.schemaVersion !== 1 || !input.repo?.owner || !input.repo?.name) {
        throw new PortError('INVALID_INPUT', '读 CI 模式：要有仓的 owner 和 name', { retryable: false });
      }
      const rows = await listIntakeRepos(db);
      const owner = input.repo.owner.toLowerCase();
      const name = input.repo.name.toLowerCase();
      const row = rows.find((r) => r.owner.toLowerCase() === owner && r.name.toLowerCase() === name);
      if (!row) {
        throw new PortError('REPO_NOT_FOUND', `没有受管仓 ${input.repo.owner}/${input.repo.name}`, {
          retryable: false,
        });
      }
      return { mode: row.ciPolicy };
    },
    // 定这张单走三段还是全程（#2826）：读标签、开关、仓档案，写一次分组记录（顺带 tasks.flow_mode）
    decideFlowMode: createDecideFlowMode({
      readLabels: async (repo, issueNumber, signal) => {
        const issue = await gh.readIssue({ repo, issueNumber, signal });
        if (!issue.labels) throw new Error(`读 ${repo.owner}/${repo.name}#${issueNumber} 没带回标签`);
        return issue.labels;
      },
      readSetting: () => readFlowModeSettingRaw(db),
      readProfile: async (repo) => {
        const row = await findRepoProfile(db, repo.owner, repo.name);
        if (!row) throw new Error(`没有受管仓 ${repo.owner}/${repo.name}，读不了仓档案`);
        return row.profile;
      },
      record: (assignment) => recordFlowAssignment(db, assignment),
      existing: (taskId) => getFlowAssignment(db, taskId),
    }),
    runSegment: createRunSegment({
      tree: { gh, trees, exec, tmpDir: join(config.stateDir, 'tmp') },
      spawner: segmentSpawner,
      runs: taskRuns,
      reservations,
      attempts: realChannelAttempts({ db }),
      memoryAdmission: realMemoryAdmission(),
      runsDir,
      sessions: oneShots,
      subagentGuard,
      reportSubagentDefs: (user, problems) => reportSubagentDefs(db, user, problems),
      log: taskLog,
    }),
    planSegmentResume: createPlanSegmentResume({
      spawner: segmentSpawner,
      getRun: (runId) => getRun(db, runId),
      latestManualRun: (taskId, startedAfter) =>
        latestRunOfTask(db, { taskId, segment: 'manual', startedAfter }),
    }),
    segmentSettled: createSegmentSettled({
      latestManualRun: (taskId, startedAfter) =>
        latestRunOfTask(db, { taskId, segment: 'manual', startedAfter }),
    }),
    selfCheck: createSelfCheck({ trees, exec, log: taskLog, ciCoverage: realCiTestCoverage(gh.client) }),
    noteBare401: createNoteBare401(db),
    taskSpend: async (input) => {
      if (input?.schemaVersion !== 1 || !input.taskId) {
        throw new PortError('INVALID_INPUT', '查这张单花掉的 token：要有 taskId', { retryable: false });
      }
      let since: Date | undefined;
      if (input.since !== undefined) {
        since = new Date(input.since);
        if (Number.isNaN(since.getTime())) {
          throw new PortError('INVALID_INPUT', '查这张单花掉的 token：起算时间不是时刻', {
            retryable: false,
          });
        }
      }
      return toTaskSpendResult(
        await taskTokenSpend(db, input.taskId, since === undefined ? undefined : { since }),
      );
    },
    coldVerify: createColdVerify({
      gh,
      // 文件接口不给 patch 的大文件，用引擎镜像里的 git 补读（#1308）
      fileDiff: mirrorFileDiff(gh),
      // 验收有结论时现读 PR 上还没解决的正式「要求改」（#2991），工作流交给下一轮动手会话
      reviewChanges,
      // 「不归我验」转给人时记下验收责任（#3037）：代码照合，单子留着等最终验收完成
      recordDuty: real.ports.acceptanceDuties,
      pickRoute: real.ports.pickRoute,
      spawner: segmentSpawner,
      runs: taskRuns,
      reservations,
      probe: probeAssigned,
      memoryAdmission: realMemoryAdmission(),
      runsDir,
      sessions: oneShots,
      log: taskLog,
      repairWorkTmp: () => repairVerifyWorkTmp(),
      onCheckoutBlocked: (alert) => raiseCheckoutBlocked(db, alert),
      onCheckoutRecovered: (recovered) => resolveCheckoutRecovered(db, recovered),
      onCheckoutCompleted: (receipt) => recordCheckoutReceipt(db, receipt),
    }),
  };
  // 临时指挥官整理待办（#1338，母单 #1335 第 3 片）：选路按用途 groom，会话和动手、验收会话同一份 Spawner 装配，登记进一次性会话的清单
  // （切号、发布排空都停得下它）；会话没有 GitHub 令牌，写操作全在引擎代码里（real/groom.ts）
  jobs.groom = groomJob({
    db,
    gh,
    trees,
    exec,
    tmpDir: join(config.stateDir, 'tmp'),
    spawner: segmentSpawner,
    pickRoute: real.ports.pickRoute,
    sessions: oneShots,
    probe: probeAssigned,
  });
  // 驾驶舱「提需求」的指挥官会话（#2061，母单 #2047 第 C 片）：和整理待办同一条路（选路用途 intake-chat、主线的只读检出、
  // 同一份 Spawner、登记进一次性会话清单），多轮 --resume 续，闲置 30 分钟收掉；会话没有 GitHub 令牌
  jobs.intakeChat = intakeChatJob({
    db,
    gh,
    trees,
    exec,
    tmpDir: join(config.stateDir, 'tmp'),
    spawner: segmentSpawner,
    pickRoute: real.ports.pickRoute,
    sessions: oneShots,
    limits: intakeChatLimitsFrom(process.env),
  });
  const evidence = realReleaseEvidence(extra.releasesDir ? { releasesDir: extra.releasesDir } : {});
  const drainControl: Omit<DrainControlDeps, 'drain' | 'log'> = {
    readRequest: () => readDrainRequest(drainRequestFile(evidence.releasesDir)),
    releaseLockBusy: () => evidence.releaseLockBusy(),
    ownSha: extra.ownSha ?? null,
    // 到截止停下三段的一次性会话（动手、验收，#957）；老 Fusion 会话端口已删，没有别的会话要停
    stopSessions: (why) => oneShots.drainStop(why),
    notify: drainNotifier({ db, machine: config.machine }),
  };
  return {
    ...real,
    jobs,
    tasks,
    drainControl,
    releaseSessions: (why) => handoff.leave(why),
    stateDir: config.stateDir,
    registerJobs: async () => {
      await registerEngineJobs(db);
      // 拼车并发上限和仓里登记的对不对得上（#194 方案 4.7）：对不上推提醒、不挡接活（拼车池由选路按 carpoolCap.view() 不派，#896）；
      // 库读不了照样抛，registerJobs 这一步不当成对上了
      await carpoolCap.check();
      // issue 归类登记不上只报错，不挡引擎接活。错误分流、停滞预判不再在这里登记。
      const issueKindRegistered = await issueKindJev.register();
      if (issueKindRegistered.level === 'error') console.error(issueKindRegistered.message);
      else console.info(issueKindRegistered.message);
    },
    retireSchedules: (client: Pick<Client, 'schedule'>) => retireEngineSchedules(client, db),
    master,
    recordSkippedRun: async (jobId, why) => {
      const at = new Date();
      const id = await startScheduleRun(db, jobId, at);
      await finishScheduleRun(db, id, { outcome: 'partial', why }, at);
    },
    closeInterruptedScheduleRuns: (input) => closeInterruptedScheduleRunsInDb(db, input),
    jobLastStartedAt: async () =>
      new Map(
        (await scheduleHealth(db)).flatMap((h) =>
          h.lastRun ? [[h.job.id, h.lastRun.startedAt] as const] : [],
        ),
      ),
    close: async () => {
      await wakeClient
        .close()
        .catch((error: unknown) => console.error('叫醒用的 Temporal 连接没关干净', errMessage(error)));
      await close();
    },
  };
}
