// 失败分流的说法：下一步动作（#1072 瘦身后只产出 retry、park 两种；swapRoute、swapModel 留在类型里是因为任务工作流的历史和
// 兜底梯还认它们），处置按「打断原因」分五种写成一张表（classify.ts 的 POLICY；依据 509 §九、docs/decisions/0010 第 7 条）。
// 本目录全是纯函数：不取时钟、不碰网络和文件，时间由调用方传进来。

import { count, nonNegative, resolvePolicy } from './policy.ts';

/**
 * 下一步动作。名字和引擎兜底梯一样，可以直接接。分流自己给 retry 和 park；换模型由路由熔断和人去做。
 * 正常分流不再换路由，除了出在账号池上的停（登录失效、封号、设备被撤销）：那一档给 swapRoute，单回去选路，
 * 池照旧暂停。swapRoute 其余只剩分流出错时的兜底梯，以及历史里已经记下的判断。
 */
export type FailureAction = 'retry' | 'swapRoute' | 'swapModel' | 'park';

/** 这个任务在这一步上已经用掉的处置次数。缺的 = 从没用过。 */
export interface AttemptCounters {
  /** 原路重试（含等上游给的时间）。 */
  retries: number;
  /** 返工：测试红、合并冲突、没交付——和基础设施的重试分开记（windsurf-dao#1755：CI 修复轮吃光审查轮次）。 */
  reworks: number;
  /** 下面两项分流不再用（没有换路由、换模型这一级了），留着是因为任务工作流的计数和历史里有它们。 */
  routeSwaps: number;
  modelSwaps: number;
}

/** 一次失败的证据。能给的都给；分类用全文，展示时才截。 */
export interface FailureEvidence {
  /** 出在哪一步：`session:<阶段>`（AI 会话）、`pushBranch`、`createWorktree`…… */
  source?: string;
  /** 阶段类型（@fleet-dao/shared 的 StageKind）；不给就从 source 的 `session:<阶段>` 取。 */
  stage?: string;
  channelId?: string;
  poolId?: string;
  routeId?: string;
  modelId?: string;
  /** 执行方式（@fleet-dao/shared 的 HostId）。 */
  hostId?: string;
  /**
   * 这个池是 Claude 订阅的哪个组织（pools.org_kind：拼车、独享）。带了的额度用满不原地睡到清零（design 第九节
   * 「拼车用完，切独享接着干」）：两个组织共用一个会话用户，这个池用满了引擎切号，回去选路、切了就换到切过去的池接着干。
   * 不给 = 不是这种池，照普通的走。
   */
  orgKind?: 'carpool' | 'solo';
  /** 出事的机器（给人看的名字，例如「法国」）和会话用户：只有人能修的（重新登录）要写清去哪台机器、以谁的身份修。 */
  machine?: string;
  runAsUser?: string;
  /** Temporal 活动超时时记录的活动名和配置的 StartToClose 时长。 */
  activity?: string;
  startToCloseSeconds?: number;
  /** 活动最后一次心跳来自哪个引擎进程；只在有确切心跳凭据时填写。 */
  engineStartedAt?: string;
  /** 当前接手失败判断的引擎进程启动时刻。 */
  currentEngineStartedAt?: string;
  /** 旧活动的心跳进程和当前引擎不同，才允许绕过重复原文短路。 */
  engineRestarted?: boolean;
  /** 这一步跟路由绑不绑定（AI 会话绑定；建树、推分支、开 PR 不绑定）。不给：有 routeId 或 source 是 `session:` 就算绑定。 */
  routeBound?: boolean;
  /** 结构化错误码：插头判定的原因（quota_exhausted、model_mismatch……）、端口的 PortError.code、Temporal 的 TIMEOUT_*、mirasim 的结束码。 */
  code?: string;
  /** 端口说能不能重试；null / 不给 = 没说。 */
  retryable?: boolean | null;
  exitCode?: number | null;
  signal?: string | null;
  httpStatus?: number;
  /** 上游错误原文，全文（调用方先脱敏）。 */
  message?: string;
  /** 最后几段过程记录（老的在前）。只有写明「读过程记录」的规则才看它：助手自己写的正文里常有 429、503 这类字样。 */
  transcriptTail?: readonly string[];
  /** 上游给的等待：Retry-After 的秒数。 */
  retryAfterSeconds?: number;
  /** 上游给的恢复时刻（额度窗清零），ISO。 */
  resetsAt?: string;
  /** 现在，ISO。算「等到几点」要它；不给就只用默认时长。 */
  now?: string;
  attempts?: Partial<AttemptCounters>;
  /** 这一步上一次失败的原文。一字不差再犯 = 重试不会变，不在原路再试（windsurf-dao#1237）。 */
  previousMessage?: string;
  /**
   * 这个账号池在短时间里已经出现过一次只凭 HTTP 401 的失败（工作流传进来）。
   * 不给 = 没有。只有「只凭 401」才看它：第二次才整池暂停。明确的登录失效、封号、设备被撤销不看它。
   */
  priorBare401?: true;
}

/** 所有任务一起避开的范围（路由探针把整池暂停用它）。 */
export interface Avoid {
  /** route = 这一条路由；pool = 整个账号池（额度、封号、登录失效）；model = 这个模型。 */
  scope: 'route' | 'pool' | 'model';
  /** 所有任务一起避开（写进共享的路由 / 账号池状态），不只是这个任务。 */
  shared: boolean;
  /** 避到几点；没有 = 等人处理完再放开。 */
  until?: string;
}

export interface FailureVerdict {
  action: FailureAction;
  /** 重试前等多久；别的动作是 0。 */
  delaySeconds: number;
  /** 一句白话。 */
  reason: string;
  /** 命中的规则编号；FB = 认不出走兜底。 */
  rule: string;
  /** 规则的白话名。 */
  title: string;
  /** 怎么认出来的：结构化的码、已知原文、只剩状态码或退出码、兜底。 */
  via: 'signal' | 'text' | 'generic' | 'fallback';
  /** 规则的第一选择；和 action 不同说明那一级的次数用完、往下走了。 */
  classifiedAs: FailureAction | 'unknown';
  /** 要不要报警（挂起一定报警）。 */
  alert: boolean;
  /** 调用方该给哪个计数加一；挂起时是 null（引擎挂起后清零重来）。 */
  counter: keyof AttemptCounters | null;
  /**
   * action 是 retry、延迟是在等上游恢复时给：quota = 等账号池额度清零（等人、排队一样不算墙钟预算），
   * upstream = 等上游给的别的时间（限流、繁忙、GitHub 暂时不让访问）。
   */
  wait?: 'quota' | 'upstream';
  /** 整池暂停：同一个池的别的任务也不该再派过去（挂起的也要给——设备被撤销时这个任务挂起，同一个池的别的任务也不该再派）。 */
  shared?: Avoid;
  /**
   * 出在账号池上，这张单不挂起，回去选路。
   * pool = 整池暂停（shared 照旧）并报警，避开这个池；
   * route = 只凭一次 HTTP 401，按临时失败换一条路由，不暂停整池。
   * 缺 = 按 action 办（不绑路由的登录失效、以及别的 stop，仍是 park）。
   */
  authReroute?: 'pool' | 'route';
  /** 只有人能修、修法确定时给：写给人看的一句（填好了机器、会话用户）。 */
  humanFix?: string;
  /** 这一步之后（等完、或挂起后人点「继续」）续同一个会话、同一条路由；false = 下一次照常选路。 */
  resumeSame: boolean;
  /** 喂熔断：fail = 算这条路由的失败；neutral = 不算（我们自己停的、断流、账号池的事、任务自己的问题）。 */
  routeOutcome: 'fail' | 'neutral';
  /** 既没有原文，也没有认得出的码：「缺原因」单独计数，别和「认不出」混在一起（旧系统 82 条这样的没人数）。 */
  missingReason?: true;
  /**
   * 原路再试前歇多久按哪一档、依据什么定（决定 0093，借 magpie gateway-routing 的分档冷却）：
   * quota = 额度用完，歇到清零时刻（resets：读到了上游给的时刻；estimate：没读到，按默认估计）；
   * rate = 限流、繁忙，按上游给的时间（retry-after），没给按默认起翻倍（backoff）；
   * other = 别的临时失败，绑路由的从 routeRetryBaseSeconds 起翻倍、封顶 retryMaxSeconds（backoff）。
   * 只在原路再试（retry）时给；返工、续干、停下不给。
   */
  cooldown?: { tier: 'quota' | 'rate' | 'other'; by: 'resets' | 'retry-after' | 'estimate' | 'backoff' };
}

/** 上限与时长：每种打断原因的「总次数 + 最长等待」两个上限都从这里来（509 §九、0010 第 7 条）。 */
export interface FailurePolicy {
  /** 原路重试几次（引擎 limits.retryAttempts）。 */
  retryAttempts: number;
  /** 返工几轮（设计第五节：审查意见最多 2 轮；返工另记一本账）。 */
  reworkRounds: number;
  /** 退避：从这里起翻倍，封顶 retryMaxSeconds（与引擎兜底梯同一条算法）。 */
  retryBaseSeconds: number;
  retryMaxSeconds: number;
  /**
   * 绑路由的别的临时失败（认不出的、没写起步时长的临时规则）从这里起翻倍，封顶 retryMaxSeconds（决定 0093：
   * magpie 按错种分档冷却，「其他」1 分钟起翻倍）。不绑路由的（建树、推分支）仍从 retryBaseSeconds 起。
   */
  routeRetryBaseSeconds: number;
  /** 最长等待：额度要等更久才恢复，就停下报警，不闷头睡几天。 */
  waitMaxSeconds: number;
}

export const DEFAULT_FAILURE_POLICY: Readonly<FailurePolicy> = Object.freeze({
  retryAttempts: 2,
  reworkRounds: 2,
  retryBaseSeconds: 15,
  retryMaxSeconds: 600,
  routeRetryBaseSeconds: 60,
  waitMaxSeconds: 6 * 3600,
});

const FAILURE_POLICY_BOUNDS = {
  retryAttempts: count(0),
  reworkRounds: count(0),
  retryBaseSeconds: nonNegative,
  retryMaxSeconds: nonNegative,
  routeRetryBaseSeconds: nonNegative,
  waitMaxSeconds: nonNegative,
} as const;

/** 缺的取默认值，给了但不对的报错（引擎的上限对象可以直接传进来，多出来的字段不管）。次数可以是 0（跳过那一级）。 */
export function resolveFailurePolicy(partial?: Partial<FailurePolicy>): FailurePolicy {
  return resolvePolicy('失败分流策略', DEFAULT_FAILURE_POLICY, FAILURE_POLICY_BOUNDS, partial);
}
