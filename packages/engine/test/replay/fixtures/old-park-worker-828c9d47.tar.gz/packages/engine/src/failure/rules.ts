// 规则表：认出来的失败 → 属于哪一种打断原因（kind），每一种怎么办写在 classify.ts 的 POLICY 表里（#1072 瘦身：一条一条各写一套
// 梯子、避开范围、记账方式删了，处置只看 kind；这里只管「认」）。每条规则至少有一条样本夹具
// （test/failure/fixtures/failure-samples.json），夹具说明出处；只有合成样本的规则在夹具测试里点名列出。
//
// 认的顺序是三轮，每轮内按表里的先后：
//   1. 强码：原因码（account_banned、quota_exhausted、TIMEOUT_HEARTBEAT……），含原文里嵌着的 JSON 码——命中即终判；
//      标了 codeFieldOnly 的规则只认证据的 code 字段，原文里捞出来的不算；
//   2. 已知原文：上游错误原文（和少数写明读过程记录的规则）；
//   3. 只剩状态码、退出码、信号，或症状码（idle_timeout、not_delivered……）：原文认得出原因时让原文说了算。
// 状态码只在语义稳定时单独定类（401、402、429、5xx）；422 永远不单凭状态码定类（mirasim 用它表示繁忙、断网、
// 没账号十几种情况，GitHub 用它表示请求校验失败）。

import type { Scan } from './scan.ts';

/**
 * 打断原因的五种（509 §九「重试不判、按表办」：额度满/被切号、进程死/网络断、测试红、同一个原因连续挂 2 次停下报人，
 * 加上「我们自己停的」「只有人能修的」两种）。每种怎么办见 classify.ts 的 POLICY。
 * - resume：我们自己要停的（切号、发布排空）：马上接着干，不记账、不设上限、不看上一次的原文；
 * - wait：上游给了时间的等待（额度清零、限流、繁忙）：等到那个时刻再来，等太久（超过最长等待）就停下报人；
 * - retry：临时的（网络、上游出错、进程被杀、起不来）：原路重试，退避翻倍，次数用完停下报人；
 * - rework：返工（测试红、合并冲突、没交付、卫生检查拦下）：退回会话去改，轮数到顶停下报人；
 * - stop：只有人能修或不能自动再来（登录失效、封号、没权限、配置不对、缺材料……）：停下报警，写清原因。
 */
export type Kind = 'resume' | 'wait' | 'retry' | 'rework' | 'stop';

export interface FailureRule {
  id: string;
  /** 白话名，进原因和驾驶舱。 */
  title: string;
  kind: Kind;
  /** 强码（第 1 轮）。小写。 */
  codes?: readonly string[];
  /**
   * 强码只认证据的 code 字段（插头、端口交来的结构化码），不认从原文里捞出来的：这个词常出现在测试输出、
   * 源码片段里（fleet-dao 自己的测试就满是），原文里有它不说明这一步是这么失败的。
   */
  codeFieldOnly?: true;
  /** 已知原文（第 2 轮）。不带 g 标志。 */
  text?: RegExp;
  /** 过程记录里的已知句子（第 2 轮）；只收很具体的句子，助手正文里常有错误字样。 */
  transcript?: RegExp;
  /** 第 3 轮。 */
  statuses?: readonly number[];
  exitCodes?: readonly number[];
  signals?: readonly string[];
  /** 症状或结局码（第 3 轮）。小写。 */
  weakCodes?: readonly string[];
  /**
   * 出在整个账号池或这台机器上（登录失效、封号、余额不够、设备被撤销）：这个池整池暂停，同一个池的别的任务也不该再派过去
   * （路由探针按它把池暂停，real/route-probe.ts）。
   */
  hold?: true;
  /**
   * 额度用满：等待记成「等账号池额度清零」。出在 Claude 订阅池（带组织类型的：拼车、独享共用法国唯一的会话用户，同一时刻只有
   * 挂着的那个能派，这个池用满了引擎切号，#157）时不原地睡到清零：马上回去选路等这条路由，切了号就换到切过去的池接着干。
   */
  quota?: true;
  /** 这条规则最多原路重试几次（和策略上限取小）。 */
  maxRetries?: number;
  /** 退避起点（秒）；不给用策略的。 */
  retryBaseSeconds?: number;
  /** wait 读不出上游时间时，第一次等多久（秒），之后翻倍；不给用策略的退避起点。 */
  defaultWaitSeconds?: number;
  /** 喂熔断：算不算这条路由的失败。 */
  routeOutcome: 'fail' | 'neutral';
  /** 原路再试时怎么试（接在原因后面）。 */
  hint?: string;
  /** 只认不是 AI 会话的步骤（GitHub 的报错）：AI 渠道报同样的字，说的是它自己的事。 */
  stepsOnly?: true;
  /**
   * 只有人能修、而且修法是确定的：写给人看的一句（「要人拍」通知的正文）。{machine}、{user}、{pool} 由证据填，
   * 证据没给的写「（没报）」，不瞎猜。
   */
  humanFix?: string;
  /** 停下后人点「继续」时续同一个会话（同一条路由）：修的是这台机器或这个池，不是任务本身。 */
  resumeAfterPark?: true;
  /**
   * 上游临时故障：验收撞上就等一会儿再验，不停下报人。整条规则打标，这条规则认得出的其余说法
   * （500、连不上、按分钟限流）验收也等。不在验收里另写关键词。
   */
  blip?: true;
}

/** 按分钟限流的原文（RL1）；拼车被拒分流（jobs/carpool-outage.ts）也按它认「不是额度用满」。 */
export const RL1_TEXT = /\bper[ -]?(?:second|minute|min)\b|\b(?:requests?|tokens?) per\b|每(?:秒|分钟)/i;

export const RULES: readonly FailureRule[] = [
  // 在途工作流重放对不上现在的代码：重试只会每轮再撞一次（windsurf-dao#1633）。
  {
    id: 'EN2',
    title: '在途任务和现在的引擎代码对不上',
    kind: 'stop',
    codes: ['tmprl1100'],
    text: /TMPRL1100|Nondeterminism error/i,
    routeOutcome: 'neutral',
  },
  // 下面两条是插头「没查成」（packages/adapters/src/judge.ts）：launch_unknown = prompt 发出去了、没等到本次的应答，
  // 会话可能已经在跑；relay_unknown = 会话说做完了、中转账本没读成，上游有没有真干活核实不了，活可能已经交了。
  // 插头先按工作目录和起针时间对过账（MS-18），对上唯一一条就自己接上了；交到这里的是对不上（没有、多条、档案读不了）。
  // 原路重试都是再起一个会话：同一件活跑两遍、扣两次额度、同一棵树里两个会话。所以只挂起报警，等人看过再对；
  // 是我们没查成，不是路由坏了，不记路由的失败。强码一轮按表的先后认，这两条只排在 EN2（同样只挂起）后面：
  // 原话里常夹着等应答时收到的别的报错（at capacity、overloaded_error、account_banned……），排在繁忙、封号这些规则
  // 后面就会被抢走。反过来，这两个词只认插头交来的 code 字段：测试输出里有这两个词（CI 红时常见）不能把返工判成挂起。
  // 旧系统同一件事的原文「没收到 prompt 的应答帧」（夹具 S09）也归 ST2：起没起成同样不知道，
  // docs/reference/errors.md 第 5 节 S09 原判 retry-here，以这条为准（PR #14 复审拍板）。只认以这句开头的整条报错，
  // 测试输出、源码片段里带着这句不算（夹具 X61）。
  {
    id: 'ST2',
    title: '起会话没查成，可能已经在跑',
    kind: 'stop',
    codes: ['launch_unknown'],
    codeFieldOnly: true,
    text: /^起会话没查成：没收到 prompt 的应答帧/,
    routeOutcome: 'neutral',
  },
  {
    id: 'DL3',
    title: '中转有没有真干活没查成',
    kind: 'stop',
    codes: ['relay_unknown'],
    codeFieldOnly: true,
    routeOutcome: 'neutral',
  },
  // 我们自己停的不算失败，也不进路由的失败率（旧系统 236 条 interrupted 里 231 条是自己停的）。
  {
    id: 'OU1',
    title: '我们自己停的，不算失败',
    kind: 'retry',
    codes: ['aborted', 'interrupted', 'cancelled', 'canceled'],
    retryBaseSeconds: 0,
    routeOutcome: 'neutral',
  },
  // 叫停时调用方给了原因（adapters 的 StopReason，#2366）：看门狗、租约过期不是「我们要停的」，是会话出了问题被收掉——
  // 记账（进路由失败率、按退避重试、凑得上「同因连挂」）。发版暂停、换路由、人点停、时限这类仍是上面的 OU1。
  {
    id: 'AB1',
    title: '看门狗或租约过期叫停',
    kind: 'retry',
    codes: ['aborted_watchdog', 'aborted_lease_lost'],
    codeFieldOnly: true,
    routeOutcome: 'fail',
    hint: '被看门狗或租约过期收掉，原路重试',
  },
  // 切号（#59）：会话用户要换组织，引擎先把手上的 Claude 会话停下、切过去，再接着干——三段的一次性会话在原分支上重跑这一段
  // （任务工作流，提示词里写着上一次为什么停），Fusion 的会话续同一个会话（换了池 fork 续上，上下文大了带接力任务书）。是我们
  // 要停的：不算失败、不进路由失败率、不记重试的账、不看上一次的原文（切几次接着干几次，不会因为切号挂起、凑成「同因连挂」），
  // 马上接着干——切号那十几秒选路回「过一会儿再选」，切完就选到切过去的那个池。码只认插头、端口交来的结构化码。
  {
    id: 'OS1',
    title: '切号：先停下，切过去接着干',
    kind: 'resume',
    codes: ['org_switch'],
    codeFieldOnly: true,
    retryBaseSeconds: 0,
    routeOutcome: 'neutral',
    hint: '切完在原分支上接着干（一次性会话重跑这一段，Fusion 的会话换了池 fork 续上）',
  },
  // 发布前排空（drain.ts）：引擎要发新版本、在停，这次没起会话。是我们自己要停的：不算失败、不记账，马上回去选路——
  // 选路在排空时回「过一会儿再选」，新引擎起来、或者发布没成撤了请求，就接着派。码只认端口交来的结构化码。
  {
    id: 'ES1',
    title: '引擎在为发布排空，这次没起会话',
    kind: 'resume',
    codes: ['engine_stopping'],
    codeFieldOnly: true,
    retryBaseSeconds: 0,
    routeOutcome: 'neutral',
    hint: '新引擎起来接着派',
  },
  // 发布前排空到了宽限的截止（drain.ts，RELEASE_GRACE_MS），还在跑的会话按切号那一套停下；或者引擎收到停机信号的那一刻会话被信号杀掉
  // （kill-evidence.ts 对上了时刻）。是我们自己要停的：不算失败、不进路由失败率、不记账，新引擎起来按编号续同一个会话。
  {
    id: 'KL3',
    title: '要发新版本，先停下、新引擎起来接着干',
    kind: 'resume',
    codes: ['engine_stop'],
    codeFieldOnly: true,
    retryBaseSeconds: 0,
    routeOutcome: 'neutral',
    hint: '新引擎起来按编号续同一个会话',
  },
  // 看门狗在会话还在跑、健康检查超时（服务单线程能堵几十秒）时重启了 fleet-mirasim-session：令牌文件被换掉，
  // 会话被杀（claude exited 143）。引擎去列 .mirasim/run 没有令牌，原文落成「没有终帧：读状态的连接建不起来：
  // …没有 local-<端口>.token」。这是我们自己把会话杀掉的，不是路由坏了：马上续跑，不进路由失败率，
  // 原文再一样也不挂起（#2186 两次动手撞同一句，第二次被「认不出」挂起）。
  // 只认「读状态的连接建不起来」这句：服务从来没起来时是「没起来：…没有令牌」，那是没配好，不在这里无限续。
  {
    id: 'MR1',
    title: 'Mirasim 服务重启把会话杀掉了',
    kind: 'resume',
    text: /读状态的连接建不起来：[^\n]*没有 local-<端口>\.token/,
    retryBaseSeconds: 0,
    routeOutcome: 'neutral',
    hint: '服务起来后续跑同一个会话',
  },
  // 这台机器的 reclaude 登录被撤销（reclaude 文档「设备被自动撤销」：同号多机同时高频用会触发风控，自动撤销设备，
  // 请求拿到 401 device_revoked；修法只有人在那台机器上、以那个用户重跑 reclaude login）。不是额度用满、也不是封号：
  // 等清零都没用，这个池在这台机器上整池暂停。这张单不挂起：回去选路避开这个池（classify 的 authReroute）；
  // 只有避开之后一条能派的路由都没有，工作流才挂起。重新登录后再派到这个池。
  // 认的两句都有出处：401 device_revoked 是 reclaude 文档原文（夹具 X05），「此设备已被解绑」是旧系统生产记录（夹具 S05）；
  // 两句在会话流里真实长什么样（插头交来的 detail 怎么拼）还没有真样本。
  {
    id: 'DV1',
    title: '这台机器的 reclaude 登录被撤销',
    kind: 'stop',
    hold: true,
    codes: ['device_revoked'],
    text: /此设备已被解绑|device[_ ]revoked/i,
    routeOutcome: 'neutral',
    humanFix: '在{machine}上以{user}重跑 reclaude login，按登录流程在浏览器里批准；然后在驾驶舱点「继续」',
    resumeAfterPark: true,
  },
  // 封号：原文还写着「请稍后重试」，照做只会在同一个池里反复撞（独享号被封，reclaude 实测）。
  // 整池暂停，这张单回去选路避开这个池，不把整张单挂起。
  {
    id: 'AU1',
    title: '账号被封',
    kind: 'stop',
    hold: true,
    codes: ['account_banned'],
    text: /当前绑定账号暂不可用|account[_ ]banned/i,
    routeOutcome: 'neutral',
  },
  // 中转（Mirasim）把上游额度用完、欠费的通知当成回答回来：会话「正常结束」，回答整段就是那条通知（插头 relayQuotaNotice 认，
  // #2249：「Your quota is exhausted. API key status: exceeded … USDT balance: -2.16 USDT」）。欠的是中转后面这一路上游
  // 的账（同一个中转池的别的模型照样能用，那次同池的 sonnet 半小时前还交了活），不是时间窗：等清零没用，要充值，所以不按 QT1 原路等，
  // 也不整池暂停。动手会话撞上先自动换一条路由重派（task-support.ts 的 AUTO_REDISPATCH_CODES），不挂起；路由探针撞上判这条
  // 路由不通，充值后探通自己恢复。码只认插头交来的 code 字段：回答、测试输出里出现这些词不算。
  {
    id: 'QT3',
    title: '中转这一路额度用完或欠费',
    kind: 'stop',
    codes: ['relay_quota_exhausted'],
    codeFieldOnly: true,
    routeOutcome: 'neutral',
  },
  // 余额、欠费、订阅权益：只有花钱才回得来，归人闸。不许自动切到按量计费的路由——那是选路的事。
  {
    id: 'QT2',
    title: '余额不够或订阅不含这项',
    kind: 'stop',
    hold: true,
    codes: [
      'insufficient_quota',
      'insufficient_balance',
      'insufficient_credits',
      'payment_required',
      'billing_hard_limit_reached',
      'cloud_plan_required',
      'cloud_plan_not_served',
    ],
    text: /payment required|insufficient[_ ](?:balance|credits?|quota|funds)|out of credits|credit balance|exceeded your current quota|billing|余额不足|充值|欠费/i,
    statuses: [402],
    routeOutcome: 'neutral',
  },
  // 按分钟限流几十秒就恢复；当成额度用满去停账号池，一条报错停过一个挂着 28 条路线的池（旧 failure-class 的真实事故）。
  {
    id: 'RL1',
    title: '按分钟限流',
    kind: 'wait',
    text: RL1_TEXT,
    maxRetries: 1,
    defaultWaitSeconds: 60,
    blip: true,
    routeOutcome: 'fail',
  },
  // 时间窗额度用满（5 小时、周、月）。design 第一节「会话断了接着干」：挂起到清零时刻，续上同一个会话，
  // 不开新的；要等太久（超过 waitMaxSeconds，例如周限）才换到别的池（换用户的接续由会话端口定：fork 续或接力任务书）。
  // Claude 订阅池（拼车、独享共用一个会话用户）不原地睡到清零：这个池用满了引擎会切号（#157），睡着的活就一直等到
  // 清零、白放着切过去的那个组织。所以马上回去选路：没切就等这条路由，切了号这条路由派不了，照常选到切过去的那个池接着干
  // （一次性会话在原分支上重跑这一段，Fusion 的会话 fork 续上；第九节「拼车用完，切独享接着干」，#59）。
  // 两种都把这个池记成「所有任务一起避开到清零」（按上游给的时间）。
  {
    id: 'QT1',
    title: '额度用满',
    kind: 'wait',
    quota: true,
    codes: ['quota_exhausted', 'cloud_exhausted', 'usage_limit_reached', 'usage_limit_exceeded'],
    // 「(not your usage limit)」是 Claude Code 在服务端临时限流时自带的一句，说的恰恰不是额度用满：否定句不认。
    text: /(?<!\bnot (?:your |a |the )?)usage limit|额度已用完|额度用完|额度用尽|quota (?:is )?exhausted|weekly limit|monthly limit|周限|\b5[- ]?hour limit/i,
    defaultWaitSeconds: 900,
    routeOutcome: 'neutral',
  },
  // mirasim「自有」档在这台机上没有账号：原文的处方是换路由（现在由人换，#1072：分流不再自己换路由），不是账号失效，不停池。
  {
    id: 'AU4',
    title: '这台机上没有这个执行体的自有账号',
    kind: 'stop',
    codes: ['local_no_account'],
    text: /本机没有这个智能体的账号/,
    routeOutcome: 'fail',
  },
  // reclaude 只认 Claude Code 自己的流量；别的客户端穿过去会被上报，攒多了设备被解绑、且不能自己恢复。
  {
    id: 'AU3',
    title: 'reclaude 拒了非 Claude Code 客户端',
    kind: 'stop',
    codes: ['non_cc_client'],
    text: /仅支持 Claude Code 客户端/,
    routeOutcome: 'fail',
  },
  // cursor-agent 的认证没过：-p 模式下 stderr 几行、退出 1、没有任何 JSON。法国用 API 密钥认证（
  // 浏览器登录在没有桌面的服务器上存不下），原话取自发行包 2026.09.23、2026.09.26：密钥换令牌被拒（无效、被撤、过期）是
  // 「⚠ Warning: The provided API key is invalid.」（插头去掉了它自带的终端颜色），拉模型清单时被拒是「Authentication
  // failed: your Cursor credentials or API key are invalid or expired.」，常驻的 worker 是「Your authentication is
  // invalid.」；一样凭据都没有是「Error: Authentication required. Please run 'cursor-agent login' first, or set
  // CURSOR_API_KEY environment variable.」「Authentication required to use Cursor Agent. Please run 'cursor-agent login'
  // to authenticate.」（命令名随起法变，agent / cursor-agent）；ACP 那条路上是「Backend rejected authentication」。
  // 和 AU2 一样整池暂停，修法是确定的：去 Cursor 后台重新生成一把密钥、放进那台机器。排在 AU2 前面：AU2 的
  // 「authentication failed / required」也认得它，但 AU2 管各家的登录，没写修法。
  {
    id: 'AU5',
    title: 'Cursor 登录失效',
    kind: 'stop',
    hold: true,
    text: /run '(?:cursor-)?agent login'|Authentication required to use Cursor Agent|Backend rejected authentication|provided API key is invalid|API key are invalid or expired|Your authentication is invalid/i,
    routeOutcome: 'neutral',
    humanFix:
      '去 Cursor 后台（cursor.com/dashboard/api）重新生成一把 API 密钥，照 docs/ops.md 第五节「会话用户的 Cursor 密钥」那条命令放进{machine}（{user}家里的 ~/.cursor/fleet-api-key），旧的那把在后台撤掉；然后在驾驶舱点「继续」',
    resumeAfterPark: true,
  },
  // 引擎起 Cursor 会话、探针之前，会话用户家里的 API 密钥文件没放好（不在、空的、不是它的、权限不是 600、是符号链接、
  // 里面不只一行密钥）：起 cursor-agent 的那段 sh 不往下起，报「Cursor 密钥没放好：<哪里不对>。文件是 <路径>，…」、
  // 退出 78（real/hosts.ts 的 CURSOR_KEY_SCRIPT）。认的时候连「哪里不对」一起摘（到句号为止），进「要人拍」的提醒。
  // 这台机器上 Cursor 的池全都起不来，重试、换这个池的路由都没用：整池暂停，照原因放好再继续；是机器没配好，不算路由的账。
  {
    id: 'AU6',
    title: 'Cursor 密钥没放好',
    kind: 'stop',
    hold: true,
    text: /Cursor 密钥没放好：[^。⏎\n]*/,
    routeOutcome: 'neutral',
    humanFix:
      '照原因把{machine}上{user}的 Cursor 密钥放好（docs/ops.md 第五节「会话用户的 Cursor 密钥」：~/.cursor/fleet-api-key 属它自己、600、只有一行密钥、不带换行，重放用那一节的命令）；然后在驾驶舱点「继续」',
    resumeAfterPark: true,
  },
  // grok（SuperGrok 订阅的 Grok Build 命令行，#266）没登录或登录续不上：无头模式一样凭据都没有是「Not signed in. To authenticate
  // without a browser, run: grok login --device-code …」（error 帧和 stderr 各一遍、退出 1，法国实跑；源码
  // crates/codegen/xai-grok-pager/src/headless.rs 的 auth_required_message）；登录过期、续不上是「Token expired. Run `grok login`
  // to re-authenticate.」「Authentication rejected by server. Run `grok login` …」「Your session has expired. Run `grok login` to
  // sign in again.」「Authentication could not be refreshed. Run `grok login` …」「Auth recovery exhausted; re-authentication
  // required.」「Not logged in. Run `grok login`.」（xai-org/grok-build f0e3be1 的 crates/codegen/xai-grok-login/src/error.rs）。
  // 修法是确定的：在那台机器上以会话用户跑 grok login --device-code、在任意设备的浏览器里确认。排在 AU2 前面：AU2 的
  // 「token expired」「not logged in」也认得几句，但它没写修法。续期时一时连不上是「auth refresh failed: …」，不带 grok login，
  // 不在这里认（不是要人重登）。没真管道时读 /dev/stdin 报的「No such device or address (os error 6)」不是没登录（起法坏了，归 CF1）。
  {
    id: 'AU7',
    title: 'Grok 登录失效',
    kind: 'stop',
    hold: true,
    text: /Not signed in\. |Run `grok login`|grok login --device-code|Auth recovery exhausted/i,
    routeOutcome: 'neutral',
    humanFix:
      '在{machine}上以{user}跑 grok login --device-code（docs/ops.md 第五节「会话用户的 grok」），在任意设备的浏览器里打开它给的链接、确认那串码；然后在驾驶舱点「继续」',
    resumeAfterPark: true,
  },
  // 登录失效要人重新登录（设备被撤销单独归 DV1，Cursor 的归 AU5、AU6，Grok 的归 AU7）。
  // 明确的登录失效（码、要重新登录的整句）：整池暂停，这张单回去选路避开这个池，不挂起。
  // 只凭 HTTP 401（状态码，或原文里只有 Unauthorized）：一次不暂停整池，按临时失败换一条路由；
  // 同一个池短时间里第二次（证据 priorBare401；时刻记在设置表，别的任务撞上的也算）才整池暂停。
  // 不绑路由的一步（推送令牌过期）仍挂起。
  {
    id: 'AU2',
    title: '登录失效',
    kind: 'stop',
    hold: true,
    codes: [
      'auth_required',
      'authentication_error',
      'unauthenticated',
      'invalid_api_key',
      'signed_out',
      'cloud_credential_expired',
      'cloud_credential_stale',
      'mint_refused',
      'local_own_auth_refused',
      'auth',
    ],
    // 只认说「要重新登录」的整句：原文里随便一个带 /login 的网址不能让整个池停下。
    // reclaude 没有有效登录时不报错退出，而是开始设备授权、打出授权链接后一直等，直到起不来被强杀（法国实测）：
    // 它 stderr 里那句「no valid login detected」就是登录失效，不能按「会话起不来」原路重起。
    text: /not logged in|please run \/login|no valid login detected|重新登录|完成登录|token (?:has )?expired|invalid (?:x-)?api[ _-]?key|authentication (?:failed|required)|unauthori[sz]ed|unauthenticated/i,
    statuses: [401],
    routeOutcome: 'neutral',
  },
  {
    id: 'RG1',
    title: '所在地区不能用',
    kind: 'stop',
    codes: ['cloud_region_unavailable', 'unsupported_country_region_territory'],
    text: /RegionError|not available in your region/i,
    routeOutcome: 'fail',
  },
  // 原文写了处方：它说换个模型。分流不再自己换模型（#1072）：停下报警，由人改路由里的模型；满的是这条路上的这个模型，
  // 别的路由上的同一个模型不一定满，这条路由的失败记进熔断。
  {
    id: 'MD2',
    title: '上游让换个模型',
    kind: 'stop',
    text: /try a different model/i,
    routeOutcome: 'fail',
  },
  // 模型不存在或已下架：停下报警，好把对应路由下线（旧系统巡检判了下架的路线还在派，windsurf-dao#1840）。
  // 常常只是这一条路由的目录里没有它，别的路由上的同一个模型照样能用，所以不整池暂停；
  // 这条路由的失败记进熔断，由熔断去下线它。
  // grok 点名的型号它不认：「Couldn't set model '<名字>': Invalid params: "unknown model id". Run 'grok models' to see available
  // models.」（error 帧和 stderr 各一遍、退出 1，法国实跑，grok 1.0.41）。
  {
    id: 'MD1',
    title: '模型不存在或已下架',
    kind: 'stop',
    codes: ['model_not_found', 'model_unavailable', 'model_retired', 'unrecognized_model'],
    text: /issue with the selected model|may not exist or you may not have access|absent from the ACP model catalog|model catalog has no match|cannot use this model|model[_ ]not[_ ]found|unknown model id|Couldn't set model '/i,
    routeOutcome: 'fail',
  },
  // 中转回 503、原文是这个模型暂时不可用（法国 2026-10-16 #2750/#2753：opus-5.5@mirasim 段已 failed，
  // 任务行仍 running、没有开着的会话，看门狗只报 idle-running，名额一直被占着）。
  // 不是 MD1：模型还在，只是这会儿上游不接。也不是 UP1：只凭状态码 503 的原路重试会钉在这条路由上睡，
  // 任务行不刷新，open_runs=0 仍算在干活。这里判停下，由动手会话换一条能派的路由；没有就停下腾出名额
  // （task-session.ts，patched('model-unavailable-redispatch')）。别的 503（没有这句）仍是 UP1。
  // 也不是 MD3：点名和读回对不上是另一句，不靠这句 503。
  {
    id: 'MU1',
    title: '模型暂时不可用',
    kind: 'stop',
    text: /model is temporarily unavailable|模型暂时不可用|模型暂不可用/i,
    routeOutcome: 'fail',
  },
  // 点名的模型和实际回话的不一样（#2742）。这一例是发版叫停后误续上一段 opus 会话，记进这条路由的失败
  // （routeOutcome fail）。当时法国在跑 0c35f93a，Mirasim 还不脱开：
  // - 前几段结局是「引擎叫停（其他：CANCELLED）」：引擎停机取消了还在跑的活动，会话收场（#2797 统计的那一种）。
  //   叫停本身不是这种失败，也不改模型。
  // - 继续时按决定 0088 续会话。resumeVerdict 只比执行方式、账号池、会话用户，不比模型；同池换模型照样续
  //   （#2119）。mirasim-relay 上的 opus-5.5 和 sonnet-5.5 是同一个执行方式、同一个池、同一个会话用户。
  //   发版后重新选路（决定 0104 已在上一版 b4686835）可以点到 sonnet，续的仍是上一段 opus。prompt 带上
  //   model=claude-sonnet-5-5 和旧 sessionKey，快照 model 仍是这段会话自己的 claude-opus-5-5[1m]。
  // - 不是比对串把 `[1m]` 剥错。modelMatches 已剥末尾方括号，剥完仍是 sonnet 对 opus。新会话若照点名起，
  //   快照在出上游请求之前就是点名加 `[1m]`（MS-29）；sonnet 在名册里，对得上，不会停。约 56 秒是服务单线程
  //   起会话的阻塞（MS-08），第一份当前轮快照就已经是 opus。
  // - 不是 #1298。那一单是新会话、点名的型号不在中转名单里，服务端换成名单第一个（gpt-6-sol → gpt-6-astra）。
  //   sonnet 在名单里。读回的是上一段的 opus，不是名单替换。
  // - 不是 MU1。那一单是上游 503「模型暂时不可用」，换路由或停下腾出名额，不是点名 sonnet 读回 opus。
  // 这里仍判停下（kind stop）：分流的结论进历史，重放读到的还是挂起。动手会话不拿第一次就把整张单挂起。
  // 新失败由 patched('model-mismatch-redispatch') 接住：停这一段，换同一模型的另一条路由、开新会话重派一次
  // （不续上一段，误续靠开新会话解开）。又对不上才停下等人；这次的标题不沿用下面这句旧的「挂起并报警」，
  // 看门狗不把它当成已经挂上的旧单叫醒。
  // 已经按「回话的模型不是点名的那个（model_mismatch）：挂起并报警」挂上的在途单，重放必须走进已经记下的挂起
  // （跳过会 TMPRL1100，变僵尸，继续信号也送不进）。看门狗认出这一句，发 taskContinue；
  // 醒来后 patched('model-mismatch-wake-reroute') 按点名开新会话重派。
  // 主线上先按点名路由重派的在途单（历史里已有 patched('model-mismatch-reroute')）重放仍走那一条，不改步序。
  // 发版排空和 Mirasim 接回不在这里改。
  {
    id: 'MD3',
    title: '回话的模型不是点名的那个',
    kind: 'stop',
    codes: ['model_mismatch'],
    routeOutcome: 'fail',
  },
  // 这条路由在这台机上起不来：版本太旧、工作区信任、参数错、模型名重名、二进制不在……重试不会变，所有任务都会撞。
  // 工作区信任：cursor-agent -p 在没信任过的目录里、没带 --trust / --force 时，stderr 打一段「⚠ Workspace Trust Required」
  // 就退出（插头固定带 --trust，撞上就是起法坏了；插头把那一句从整段里捞出来，最后一行是「Pass --trust, --yolo, or -f if you
  // trust this directory」）；带了 --trust 却写不下信任记录是「Error: Failed to trust workspace at <目录>」。
  // grok 从 /dev/stdin 读提示词要真管道：插头前面垫了一个 cat，没垫上（或者 stdin 不是管道也不是终端）时打开 stdin 报
  // 「No such device or address (os error 6)」（ENXIO，法国实跑），是起法坏了，不是没登录。
  {
    id: 'CF1',
    title: '执行方式或路由配置不对',
    kind: 'stop',
    codes: ['cli_too_old', 'agent_unconfigured', 'unsupported_capability', 'protocol_mismatch'],
    text: /Workspace Trust|if you trust this directory|Failed to trust workspace|ambiguous across providers|requires --verbose|unexpected argument|unknown option|spawn \S+ (?:ENOENT|EACCES)|No such device or address \(os error 6\)/i,
    routeOutcome: 'fail',
  },
  // 提示词拼进命令行参数超了系统上限：只有提示词长的任务撞，别的任务照用这条路由；插头该改成走 stdin 或文件。
  {
    id: 'CF2',
    title: '提示词太长，这条路由的起法塞不下',
    kind: 'stop',
    text: /\bE2BIG\b/,
    routeOutcome: 'neutral',
  },
  // 推送身份没有 workflows 权限：换有权限的身份属于改凭据，要人拍（旧系统判成可重试，退避白烧，#1725）。
  // 主线的规则集、保护不让「引擎」直写需求文档（spec_doc_rejected）同一类：重试一样被拒，要人改设置。
  {
    id: 'PM1',
    title: '没有权限',
    kind: 'stop',
    codes: ['permission_denied', 'workflows_permission', 'spec_doc_rejected'],
    text: /refusing to allow a GitHub App|without [`']?workflows[`']? permission/i,
    routeOutcome: 'neutral',
  },
  // 推分支前的卫生检查（packages/hygiene，github 的 pushBranch 推之前扫相对主线新增的行和文件名）拦下了会话交的内容：
  // 令牌、私钥、口令这类真密钥……公开仓推上去就公开了。是会话交的东西有问题：退回会话去掉再交（记返工账）；
  // 同一处连续被拦两次（端口把命中处整理成稳定的一句，和上一次一字不差）就挂起报警。
  // 推分支在新历史里不靠这一步的原地重试退回（patched('hygiene-blocked-handoff')，task-runtime 交给 task.ts）：
  // 命中处进下一轮动手会话。下面这条仍是老历史、以及开 PR 等别的步骤的处置。
  // 码只认结构化的 code 字段：测试输出、源码里常有这个词。
  {
    id: 'HY1',
    title: '卫生检查拦下了新增内容',
    kind: 'rework',
    codes: ['hygiene_blocked'],
    codeFieldOnly: true,
    retryBaseSeconds: 0,
    routeOutcome: 'neutral',
    hint: '退回会话把这些内容从提交里拿掉再交',
  },
  // 卫生检查根本扫不成（git 的输出认不出、要推的头不在扫过的提交里）：不推，也不当成「查过没事」。都是这台机器
  // 这一侧的事，不是会话的错：不退回会话，挂起报警，等人看过之后点「继续」。
  {
    id: 'HY2',
    title: '卫生检查没扫成',
    kind: 'stop',
    codes: ['hygiene_unscanned'],
    codeFieldOnly: true,
    routeOutcome: 'neutral',
  },
  // 无头会话没人批权限：同一会话里会一直被拒（原文自己说了别重试），是这条路由的起法不对。
  {
    id: 'PM2',
    title: '会话里的操作要人批，没人批',
    kind: 'stop',
    text: /Permission for this tool use was denied|no approval surface/i,
    transcript: /Permission for this tool use was denied|no approval surface/i,
    routeOutcome: 'fail',
  },
  // 活动超时、工人重启丢了活动：从检查点重跑，不交人（旧系统落成 UNKNOWN → 没查成 → 等人，fleet 任务 #1608 g1）。
  //
  // #2710（2026-10-16 约 20:29 CST，发版列车刚切过，进程 20:21 起在新提交上）：整单从 running/implement
  // 变成 stalled/parked，doing 是「引擎这边丢了这一步（timeout_start_to_close）：挂起并报警（和上一次的原文一字不差，
  // 原路再试不会变）」。这句只在本规则、且证据没标 engineRestarted 时，由「原文一字不差」打出来。
  // 归类：分类把可重试的活动超时当成「原路再试不会变」。不是另外三件：
  // - #2797 发版叫停：排空到点把会话停下，码是 engine_stop（KL3，kind resume），不记账、马上续，不进这张表。
  // - #2815 Mirasim 发版后接回：会话脱开引擎接着跑，活动交回 detached，工作流隔一会儿 attach，不以 timeout_start_to_close 收场。
  // - #2811 model_mismatch：MD3 仍是 kind stop、按路由记失败。动手会话先换同一模型的另一条路由自动重派一次
  //   （patched('model-mismatch-redispatch')，开新会话），第二次才停下等人。已经按旧标题挂上的由看门狗发继续再重派。
  //   #2742 是发版叫停后误续上一段 opus，不是活动超时。
  // timeout_* 的原文是 Temporal 固定句（activity StartToClose timeout 等），第二次必然一字不差。runSegment 的
  // StartToClose 是 75 分钟；#2710 离新进程起来只有约 8 分钟，凑不齐一次在新进程上跑满的 StartToClose。
  // 心跳还在才会落成 start_to_close，工人一死先是 timeout_heartbeat。这次没标上 engineRestarted（心跳里的启动时刻
  // 和当前进程相同，或两种凭据都不足），于是第二次原文一样就把整单挂起。
  // 分流这里仍判 park：动手会话不拿这个 park 挂整单，停掉这一段、按点名路由重派；标了 engineRestarted 的仍原路重试
  // 并续可接回的会话（task-session.ts，patched('en1-timeout-redispatch')）。没有能派的路由，或同一原因连败到重派预算
  // （先避开这条路由，同一模型再避开模型，再撞上才挂起），才 parked。
  // session_lost、exit_lost 不在这条例外里：那两句可以是真的同一处再犯，仍按一字不差挂起。
  {
    id: 'EN1',
    title: '引擎这边丢了这一步',
    kind: 'retry',
    codes: [
      'timeout_start_to_close',
      'timeout_heartbeat',
      'timeout_schedule_to_close',
      'timeout_schedule_to_start',
      'session_lost',
      // 会话脱开引擎跑、引擎不在时没了，没留下终帧和退出码（adapters 的 detached.ts）：续会话接着干
      'exit_lost',
    ],
    text: /StartToClose timeout|活动随旧进程丢失|worker 部署重启|heartbeat timeout/i,
    retryBaseSeconds: 5,
    routeOutcome: 'neutral',
    hint: '从检查点接着跑',
  },
  // 下面三条只认不是会话的步骤（开 PR、推分支、查 CI）：AI 渠道报「API rate limit exceeded」说的是它自己限流，
  // 是它自己的限流，按它自己的规则（RL3）等，不按 GitHub 限流（RL2）的写法。
  // 我方请求数据被 GitHub 校验拒了：重试不会变。不许因为 422 当成平台繁忙。
  {
    id: 'GH1',
    title: 'GitHub 拒了请求数据',
    kind: 'stop',
    text: /Validation Failed/i,
    routeOutcome: 'neutral',
    stepsOnly: true,
  },
  // GitHub 部分中断时出现过；过几分钟再试，还不行再挂起（也可能真是权限不够）。
  {
    id: 'GH2',
    title: 'GitHub 暂时不让访问',
    kind: 'wait',
    text: /Resource not accessible by integration/i,
    maxRetries: 1,
    defaultWaitSeconds: 300,
    routeOutcome: 'neutral',
    stepsOnly: true,
  },
  // 次级限流：停几分钟、串行，不按主配额的重置时间干等。
  {
    id: 'RL2',
    title: 'GitHub 限流',
    kind: 'wait',
    text: /API rate limit exceeded|secondary rate limit/i,
    defaultWaitSeconds: 300,
    routeOutcome: 'neutral',
    stepsOnly: true,
  },
  // GitHub 写操作的幂等占用还在（packages/github 的 idempotency.ts）：上一下写到一半没收到回执（maybeLanded），键留着「写到一半」，
  // 远端也没找到；占用 2 分钟（CLAIM_STALE_AFTER_MS = 120 秒）没续才算过期、才能接过来重写。原文每次一字不差，按「认不出」走
  // 15 秒退避、第二次就以「同因连挂」挂起——根本等不到过期（#1971 开 PR 这一步 47 秒内挂起，8 小时没人动）。所以按等待办：
  // 第一次等 150 秒（过期线 + 30 秒余量，翻倍），等满次数还撞就停下报人。CLAIM_LOST（占用被别的重试接过去了）同一类。
  // 码只认端口交来的结构化码（ApplicationFailure.type），原文里出现这个词不算。
  {
    id: 'GH3',
    title: 'GitHub 写操作还占着（上一下没收到回执），等占用过期再写',
    kind: 'wait',
    codes: ['in_flight', 'claim_lost'],
    codeFieldOnly: true,
    defaultWaitSeconds: 150,
    routeOutcome: 'neutral',
    stepsOnly: true,
  },
  {
    id: 'MC1',
    title: '合并冲突',
    kind: 'rework',
    codes: ['merge_conflict', 'conflicting'],
    text: /mergeable\W{0,3}CONFLICTING|merge conflict|CONFLICT \(content\)|Automatic merge failed/i,
    retryBaseSeconds: 0,
    routeOutcome: 'neutral',
    hint: '先同步最新主线再解冲突',
  },
  // 远端分支比本地新：先抓远端、并好再推。原文要留全（旧系统只留 160 字，被拒原因正好截掉）。
  // 推的不含最新主线（github 包的 BEHIND_MAINLINE）同一类：推分支的端口每次推之前先并主线，撞上只可能是并完到推之间
  // 主线又动了，原地再推一遍（端口会再并一次）。
  {
    id: 'MC2',
    title: '推送落后于远端',
    kind: 'retry',
    codes: ['non_fast_forward', 'behind_mainline'],
    text: /non-fast-forward|\(fetch first\)|Updates were rejected because/i,
    routeOutcome: 'neutral',
    hint: '先抓远端、并好再推',
  },
  // 推被拒（DIVERGED）：github-ports.ts 的 pushBranch 已经先试过认领远端新头、并一次（远端含着起会话前的头就是
  // 良性前进，不算改写），到这条规则时说明那条路也走不通——要么真被强推改写了历史，要么远端分支已经不在了。
  // 原路重试没用（改写、删分支都不会因为再试一次而变回来），得人看（#307/#389 那次真事：帅位手工并了主线又推，
  // 工作树没跟上，后来推被拒，当时落进了「认不出」的兜底梯，见文件顶部三轮认的说明；这条规则补上明确归类）。
  {
    id: 'MC3',
    title: '推送和远端真分叉了，不是良性前进',
    kind: 'stop',
    codes: ['diverged'],
    routeOutcome: 'neutral',
    hint: '看原因里远端此刻的头，人工核实要不要把它当成分支的新头接着走',
  },
  // 并主线时工作树在旧头之后还有没推的提交，远端那个并主线提交又含不了它们、本地也并不上（历史被改写，或列不出来）。
  // 能并的在 github-ports.ts 里已经并过再推了，到这条规则说明那条路走不通。原路重试没用。
  // 只认端口交来的码：原文里出现「没推的提交」不说明这一步就是这个失败。
  {
    id: 'MC4',
    title: '工作树有没推的提交，并主线并不上',
    kind: 'stop',
    codes: ['worktree_diverged'],
    codeFieldOnly: true,
    routeOutcome: 'neutral',
    hint: '看报错里的工作树和没推的提交，先取走再清树',
  },
  {
    id: 'TS1',
    title: '测试没过',
    kind: 'rework',
    codes: ['checks_failed', 'checks-failed', 'tests_failed', 'ci_red', 'ci_failed'],
    text: /契约检查未通过|\bchecks? failed\b|\bTests?\s+\d+\s+failed\b|^# fail [1-9]/im,
    retryBaseSeconds: 0,
    routeOutcome: 'neutral',
    hint: '带上失败的测试和输出',
  },
  // 交付没查成（抓取失败、git 出错）是我们查的时候出了事，不是执行体没交活：重查。
  {
    id: 'DL2',
    title: '交付没查成',
    kind: 'retry',
    codes: ['delivery_unknown'],
    routeOutcome: 'neutral',
    hint: '重查交付，不算执行体失败',
  },
  // 内存超限被内核杀掉：只认有证据的——会话端口查过 cgroup 的按内存杀进程记录交回的 oom_killed（real/kill-evidence.ts），
  // 或者原文里写着内核的 OOM 字样。从检查点重起一次；再来就是资源或任务本身的问题，交帅位。
  // 改这里之前必须知道：原来这条把所有 137、143、SIGKILL、SIGTERM 都算进来、提示写死「多半是内存超限」，把「我们自己的发布
  // 把它叫停了」盖住了（出过的两次都是发布重启引擎）。没证据的信号杀掉归 KL4，不猜。
  {
    id: 'KL2',
    title: '内存超限被内核杀掉',
    kind: 'retry',
    codes: ['oom_killed'],
    codeFieldOnly: true,
    text: /oom[-_ ]?kill|out of memory/i,
    maxRetries: 1,
    routeOutcome: 'neutral',
    hint: '从检查点重起；内存到了上限（证据见原因）',
  },
  // 被信号杀掉、查过也对不上是谁（引擎没在停、cgroup 里没有按内存杀进程的记录）：照实写没查到，从检查点重起一次，再来交帅位。
  // 只剩退出码、信号（插头的判定没经过会话端口查证据）也归这里，不猜是内存。
  {
    id: 'KL4',
    title: '进程被信号杀掉，没查到是谁杀的',
    kind: 'retry',
    codes: ['signal_unexplained'],
    codeFieldOnly: true,
    text: /\bSIGKILL\b|\bKilled\b/,
    exitCodes: [137, 143],
    signals: ['SIGKILL', 'SIGTERM'],
    maxRetries: 1,
    routeOutcome: 'neutral',
    hint: '从检查点重起一次（没查到是谁杀的，不猜）',
  },
  // 会话里的命令跑超时被杀（Claude 的 Bash 默认 2 分钟，插头放宽到 10 分钟）：接着干并提醒它换跑法，再来就交帅位。
  {
    id: 'KL1',
    title: '命令跑超时被杀',
    kind: 'retry',
    text: /Command timed out after \d+|\bExit code (?:124|137|143)\b/,
    transcript: /Command timed out after \d+|\bExit code (?:124|137|143)\b/,
    maxRetries: 1,
    routeOutcome: 'neutral',
    hint: '接着干，提醒它把长命令放后台或缩小范围',
  },
  // 没有工具在跑、又长时间没动静：原路重试（旧系统判卡死的依据是 360 秒没推进，windsurf-dao#1499）。
  {
    id: 'SL1',
    title: '会话卡住不动',
    kind: 'retry',
    text: /no progress for \d+\s*s\b|turn stalled past|session stalled/i,
    weakCodes: ['idle_timeout', 'stalled', 'session_stalled'],
    routeOutcome: 'fail',
    hint: '续一句提醒它，续不上开新会话',
  },
  // 经桥接连这个会话用户的 Mirasim 服务，等桥接报 ready 等到顶（adapters 的 bridge-connect.ts，BRIDGE_CONNECT_TIMEOUT_TEXT）：
  // 连接都没建起来，会话根本没起。这是桥接未就绪（服务单线程被堵住，或服务没在跑），不是已经在跑的会话被掐掉。
  //
  // #2710、#2742（2026-10-16 约 21:04 CST，发版列车刚切过、引擎自愈重启后约一分钟，phase 仍是 implement、
  // state 仍是 running）：last_problem 都是「桥接连 Mirasim 超时（桥接连 Mirasim 超时）：挂起并报警（已重试 1 次）」。
  // 归类：分类把可重试的桥接连接超时当成「挂起并报警」。maxRetries 是 1，第二次（原文略有差别，凑不成「一字不差」）
  // 就写出这句。不是另外四件：
  // - #2703 探针侧同一句：再探一次仍不通就判这条路由离线，不挂整单（已关）。
  // - #2815 引擎停时 Mirasim 动手会话：脱开再按交接单接回，不以这句收场。
  // - #2824 timeout_start_to_close：EN1，Temporal 活动超时，原文一字不差才挂起。
  // - #2811 model_mismatch：MD3，kind stop。分流仍判停下。动手会话先换同一模型的另一条路由自动重派一次
  //   （patched('model-mismatch-redispatch')，开新会话），第二次才停下等人。已经按旧标题挂上的由看门狗发继续再重派。
  //   #2742 是发版叫停后误续上一段 opus，不是桥接超时。
  // 分流这里仍判「原路重试一次，再不行挂起」（探针认这句，改 kind 会把探针带偏）。动手会话不拿这个挂起整单：
  // 停掉这一段、按点名路由重派；没有能派的路由，或同一原因连败到重派预算（先避开这条路由，同一模型再避开模型，
  // 再撞上才挂起），才 parked（task-session.ts，patched('mb1-bridge-redispatch')）。
  {
    id: 'MB1',
    title: '桥接连 Mirasim 超时',
    kind: 'retry',
    text: /桥接连 Mirasim 超时/,
    maxRetries: 1,
    routeOutcome: 'fail',
  },
  // 起不来：重起一次，再不行停下报警（盲设计题有一臂就这么阵亡：codex initialize timed out）。真会话端口的进程迟迟
  // 起不来（spawn_timeout，不可重试：原地同一个 runId 重试只会报已经起过）也归这里，由工作流换新 runId 原路重起一次。
  {
    id: 'ST1',
    title: '会话起不来',
    kind: 'retry',
    text: /initialize'? timed out|did not accept the session in time|没收到 state 帧|did not become ready within|session\/new timed out|迟迟没有第一帧/i,
    weakCodes: ['startup_timeout', 'spawn_timeout'],
    maxRetries: 1,
    routeOutcome: 'fail',
  },
  // 总时长到顶：第一次接着上次的进度、原路续同一个会话（maxRetries 1；工作流拿这一次的执行编号问 planSegmentResume，
  // 带上会话号再起）。同一张单、同一条路由上第二次不再原路续：
  // 失败分流判停下后，工作流避开这个模型换一条路由，带上树上的进度续一次（task-session.ts，#2244）。
  // 这条路由在这张单上只是慢、会话还在出字，再原路续白烧额度；换过去的那条再在第二次到顶，交帅位去拆。
  //
  // 强码、只认证据的 code 字段（#2759）：one-shot 到点强停，插头把叫停写成「引擎叫停（时限到了：one-shot timeout）」。
  // 句里的 timeout 是我们自己的时限，不是上游超时。这码若留在第 3 轮，第 2 轮 NT2 的 \btimeout\b 会先抢走，
  // routeOutcome 落成 fail——会话干满还在回话，半开熔断却把这次试探判成又失败、冷却翻倍。时限是我们定的，
  // 到点还在干活说明不了路由坏了，不进熔断、不进路由战绩。上游超时（HTTP 504、连接超时、ETIMEDOUT）没有这个码，
  // 仍走 UP1 / NT1 / NT2，照旧算失败。
  {
    id: 'WT1',
    title: '会话总时长到顶',
    kind: 'retry',
    codes: ['wall_clock_timeout'],
    codeFieldOnly: true,
    maxRetries: 1,
    routeOutcome: 'neutral',
    hint: '接着上次的进度续一轮',
  },
  {
    id: 'SM1',
    title: '续会话没续上',
    kind: 'retry',
    codes: ['session_mismatch'],
    routeOutcome: 'neutral',
  },
  // 某条路由对一个任务报繁忙，所有任务一起避开它，过一会儿放一个试探（设计第十二节）。
  {
    id: 'BZ1',
    title: '路由繁忙',
    kind: 'wait',
    codes: [
      'overloaded',
      'overloaded_error',
      'route_refused',
      'route_busy',
      'capacity',
      'cloud_unavailable',
      'server_overloaded',
    ],
    text: /overloaded|容量已满|at capacity|high demand|繁忙|满载/i,
    statuses: [529],
    defaultWaitSeconds: 60,
    blip: true,
    routeOutcome: 'fail',
  },
  // 没写处方的限流：上游给了时间就等那么久，没给按默认起翻倍，次数用完停下报警。
  {
    id: 'RL3',
    title: '限流',
    kind: 'wait',
    codes: ['rate_limited', 'rate_limit_error', 'rate_limit_exceeded', 'too_many_requests'],
    text: /rate[ _-]?limit|too many requests|temporarily limiting requests|限流/i,
    statuses: [429],
    defaultWaitSeconds: 60,
    blip: true,
    routeOutcome: 'fail',
  },
  // 长流半路被掐：续跑同一个会话；不进路由失败率的分母（旧系统据此把一条当天真干出活的路线判死，#1386）。
  {
    id: 'SB1',
    title: '流断了',
    kind: 'retry',
    codes: ['incomplete', 'prompt_incomplete'],
    text: /stream disconnected|stream closed before|stream (?:ended|broken)|断流|response ended prematurely/i,
    weakCodes: ['timeout'],
    blip: true,
    routeOutcome: 'neutral',
    hint: '续跑同一个会话',
  },
  // 上游内部错误：「403 Internal error during token generation」是上游的事，不因为 403 停账号池。
  {
    id: 'UP1',
    title: '上游出错',
    kind: 'retry',
    codes: ['internal_server_error', 'service_unavailable', 'bad_gateway', 'gateway_timeout'],
    text: /internal error|internal server error|server error|bad gateway|service unavailable|gateway timeout/i,
    statuses: [500, 502, 503, 504],
    weakCodes: ['transient'],
    blip: true,
    routeOutcome: 'fail',
  },
  {
    id: 'NT1',
    title: '网络不通',
    kind: 'retry',
    codes: [
      'econnreset',
      'econnrefused',
      'econnaborted',
      'etimedout',
      'epipe',
      'eai_again',
      'enotfound',
      'ehostunreach',
      'enetunreach',
      'transport_closed',
      'cloud_unreachable',
      'network',
    ],
    text: /\bE(?:CONNRESET|CONNREFUSED|CONNABORTED|TIMEDOUT|PIPE|AI_AGAIN|NOTFOUND|HOSTUNREACH|NETUNREACH)\b|socket hang up|fetch failed|connection (?:error|reset|refused|closed)|network error|tcp connect error|deadline has elapsed|error sending request|Reconnecting\.\.\.|waiting for network|Failed to reach|连不上|域名解析|建立连接失败|连接被重置/i,
    blip: true,
    routeOutcome: 'fail',
  },
  {
    id: 'NT2',
    title: '超时',
    kind: 'retry',
    // \b 挡住 idle_timeout 这类码：它们是症状码，归第 3 轮。
    // one-shot 的「时限到了：one-shot timeout」不在这里：证据码是 wall_clock_timeout，WT1 强码先拿走（#2759）。
    text: /\btimed out\b|\btimeout\b/i,
    routeOutcome: 'fail',
  },
  // 说做完了但没交付（旧系统一次零产出的假完成一路绿到合并，windsurf-dao#1572）：带着缺什么回会话；返工轮数用完停下报警。
  {
    id: 'DL1',
    title: '说做完了，但没交付',
    kind: 'rework',
    weakCodes: ['not_delivered', 'wrong_output'],
    retryBaseSeconds: 0,
    routeOutcome: 'neutral',
    hint: '告诉它缺什么',
  },
  {
    id: 'OU2',
    title: '会话被外面停掉了',
    kind: 'retry',
    weakCodes: ['session_stopped'],
    routeOutcome: 'neutral',
  },
];

export interface RuleHit {
  rule: FailureRule;
  via: 'signal' | 'text' | 'generic';
  /** 命中的那一小段（码、原文片段、状态码）。 */
  hit: string;
}

/** 三轮认：强码 → 已知原文 → 状态码 / 退出码 / 信号 / 症状码。认不出返回 undefined。 */
export function matchRule(scan: Scan, all: readonly FailureRule[] = RULES): RuleHit | undefined {
  const rules = scan.session ? all.filter((r) => !r.stepsOnly) : all;
  for (const rule of rules) {
    const code = rule.codes?.find((c) => (rule.codeFieldOnly ? scan.code === c : scan.codes.has(c)));
    if (code) return { rule, via: 'signal', hit: code };
  }
  for (const rule of rules) {
    const text = rule.text?.exec(scan.text)?.[0] ?? rule.transcript?.exec(scan.tail)?.[0];
    if (text) return { rule, via: 'text', hit: text };
  }
  for (const rule of rules) {
    if (scan.status !== undefined && rule.statuses?.includes(scan.status)) {
      return { rule, via: 'generic', hit: `HTTP ${scan.status}` };
    }
    if (scan.exitCode !== undefined && rule.exitCodes?.includes(scan.exitCode)) {
      return { rule, via: 'generic', hit: `退出码 ${scan.exitCode}` };
    }
    if (scan.signal && rule.signals?.includes(scan.signal)) {
      return { rule, via: 'generic', hit: `信号 ${scan.signal}` };
    }
    const weak = rule.weakCodes?.find((c) => scan.codes.has(c));
    if (weak) return { rule, via: 'generic', hit: weak };
  }
  return undefined;
}

/** 这条规则是不是上游临时故障（验收撞上就等一会儿再验）。认不出、没这条规则，都不是。 */
export function isUpstreamBlip(ruleId: string): boolean {
  return RULES.some((rule) => rule.id === ruleId && rule.blip === true);
}
