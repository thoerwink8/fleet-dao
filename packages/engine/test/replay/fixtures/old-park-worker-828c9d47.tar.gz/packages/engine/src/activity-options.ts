// 每个活动的超时、心跳、重试、叫停时等不等它收场：按活动类型分开设，唯一出处在这里（旧系统所有活动共用一个 74 分钟、
// 没有心跳，工人一重启丢掉的活动要干等 74 分钟才判死）。工作流按这张表给每个活动配代理，不许在调用处另写。

import { type ActivityOptions, msToNumber, type RetryPolicy } from '@temporalio/common';
import type { Limits } from './limits.ts';
import type { EnginePorts } from './ports.ts';
import type { TaskBriefResult } from './runner/task-brief.ts';
import { SELF_CHECK_ACTIVITY_MS } from './self-check-budget.ts';
import {
  type ArmAutoMergeInput,
  type ArmAutoMergeResult,
  type CheckGuardedInput,
  type ColdVerifyInput,
  type ColdVerifyResult,
  type DecideFlowModeInput,
  type DecideFlowModeResult,
  type DeliveryRead,
  type EngineStartedAt,
  type GuardedPaths,
  MERGE_POLL_MINUTES,
  type MergedTaskReceipt,
  type MergeNowInput,
  type MergeNowResult,
  type MergeWait,
  type NoteBare401Input,
  type NoteBare401Result,
  type PlanSegmentResumeInput,
  type PlanSegmentResumeResult,
  type ProbeAssignedInput,
  type ProbeAssignedResult,
  type ReadCiPolicyInput,
  type ReadCiPolicyResult,
  type ReadCiReviewsInput,
  type ReadCiReviewsResult,
  type ReadDeliveryInput,
  type ReadMergedTaskInput,
  type ReadTaskBriefInput,
  type ReleaseReservationInput,
  type ReleaseReservationResult,
  type RunSegmentInput,
  type RunSegmentResult,
  SEGMENT_MINUTES,
  type SegmentSettledInput,
  type SegmentSettledResult,
  type SelfCheckInput,
  type SelfCheckResult,
  type TaskSpendInput,
  type TaskSpendResult,
  type WaitMergedInput,
} from './task-contract.ts';

type PortActivities = {
  [K in keyof EnginePorts]: (input: Parameters<EnginePorts[K]>[0]) => ReturnType<EnginePorts[K]>;
};

/** 工作流看到的活动：端口（EnginePorts）里的，加上引擎自己的。 */
export type EngineActivities = PortActivities & {
  readMergedTask(input: ReadMergedTaskInput): Promise<MergedTaskReceipt | null>;
  /** 当前 worker 进程的启动时刻；超时分流用它和旧活动最后一次心跳作严格比较。 */
  engineStartedAt(input: { schemaVersion: 1 }): Promise<EngineStartedAt>;
  // —— 任务工作流（task-contract.ts；#632）要的活动：现读单子、起一次无头动手会话、读交付、冷验收、合并这几步 ——
  /** 现读单子和它指着的需求文档，拼出动手的交代（runner/task-brief.ts）。单子读不到抛错；缺栏回 problems。 */
  readTaskBrief(input: ReadTaskBriefInput): Promise<TaskBriefResult>;
  /** 起一次无头动手会话（one-shot）：会话没跑成回 ok:false 和证据，交给失败分流；起不来的基础设施问题抛错。 */
  runSegment(input: RunSegmentInput): Promise<RunSegmentResult>;
  /** 读会话交付的东西（工作树现在的头、比起点多几个提交、改了哪些文件）。读不到抛错，不回空。 */
  readDelivery(input: ReadDeliveryInput): Promise<DeliveryRead>;
  /** 合并之前的冷验收（换一个不同的族）。没能做出来回 unavailable，不当成没过。 */
  coldVerify(input: ColdVerifyInput): Promise<ColdVerifyResult>;
  /** 这个 PR 改到的文件里，哪些是改标准的路径（要创始人同意）。读不到抛错，不当成没碰到。 */
  checkGuarded(input: CheckGuardedInput): Promise<GuardedPaths>;
  /** 给 PR 挂上自动合并（squash，只合 expectedHead）。 */
  armAutoMerge(input: ArmAutoMergeInput): Promise<ArmAutoMergeResult>;
  /** 等 PR 合并（长轮询，到点回 waiting 由工作流再来一次）。 */
  waitMerged(input: WaitMergedInput): Promise<MergeWait>;
  /** 现读这个仓的 CI 模式（强制 / 不强制）。没有这个受管仓抛错，不当成不强制。 */
  readCiPolicy(input: ReadCiPolicyInput): Promise<ReadCiPolicyResult>;
  /** CI 红返工前现读仍有效的正式评审。读不全抛错；头变了回未交付。 */
  readCiReviews(input: ReadCiReviewsInput): Promise<ReadCiReviewsResult>;
  /** 不强制 CI 的仓：直接合并这张 PR（不等检查）。 */
  mergeNow(input: MergeNowInput): Promise<MergeNowResult>;
  /** 判这一段能不能续上一段的会话（决定 0088）：续不上回 new 加原因，不抛。 */
  planSegmentResume(input: PlanSegmentResumeInput): Promise<PlanSegmentResumeResult>;
  /** 上一段收场了没有（决定 0093）：重试、重派前问，没收场不起第二段。库读不了抛。 */
  segmentSettled(input: SegmentSettledInput): Promise<SegmentSettledResult>;
  /** 动手会话收场后在会话的树里跑测试和 tsc（决定 0093）：没跑成回 skipped，不抛。 */
  selfCheck(input: SelfCheckInput): Promise<SelfCheckResult>;
  /** 这张单到现在花掉多少 token（单任务预算，决定 0093）。 */
  taskSpend(input: TaskSpendInput): Promise<TaskSpendResult>;
  /**
   * 只凭 HTTP 401：记下这个池这一次，并回答短时间里是不是已经有过一次（所有任务共用，不单记在这张单里）。
   */
  noteBare401(input: NoteBare401Input): Promise<NoteBare401Result>;
  /** 定这张单走三段还是全程（#2826）：第一次选路之后、第一段动手之前问一次。读不到抛，工作流按三段走。 */
  decideFlowMode(input: DecideFlowModeInput): Promise<DecideFlowModeResult>;
  /** 派单前对选定的这一条路由探一次（#1409）。没装探针报 JOB_NOT_CONFIGURED，不当成探通。 */
  probeAssignedRoute(input: ProbeAssignedInput): Promise<ProbeAssignedResult>;
  /** 派前探测不通、这轮不用这条路由：放掉选路预占的名额。没装放名额报 JOB_NOT_CONFIGURED，不装作放过。 */
  releaseReservation(input: ReleaseReservationInput): Promise<ReleaseReservationResult>;
};

export type ActivityName = keyof EngineActivities;

/**
 * quick：毫秒到秒级的记账、选路由、报警——30 秒，丢了 1 分钟内重来。
 * git：推分支、开 PR、合并这类几秒到几分钟的——5 分钟，幂等，重试 3 次。
 * setup / ci：长活动——限时按活来，必须心跳，心跳超时 = 工人丢了。
 * selfCheck：动手之后的自测。不和建树（setup）同档：建树是装依赖，20 分钟、重试 3 次就够；
 * 自测自己的预算是测试加 tsc，还要在机器名额上排队。挂在 setup 上时活动限时先到，Temporal 判 StartToClose
 * 超时后整段重跑，三次都白等，什么也没测成。这一档限时把测试、tsc 和排队余量加在一起，必须心跳；只试一次，
 * 限时到了交给工作流记 skipped，不再从头跑。
 * job：派单前探测——10 分钟，不重试。
 * 派前探测自己回通或不通，不靠这一层再探一遍（Claude 一次加上隔 20 秒重试，放不进选路那一档 30 秒）。
 * 别的定时任务（对账、探针、读额度、看门狗……）不是活动了（#1072）：引擎的定时器直接跑，一轮的限时在 jobs/engine-timers.ts。
 * segment：一次无头会话（动手、冷验收）——限时是会话最长时间加一刻钟收尾，必须心跳；只试一次：会话贵又不幂等，
 * 活动失败怎么办（重试、换路由、挂起）由工作流按失败分流定，不在 Temporal 这一层自动再起一遍。
 * poll：长轮询（等合并）——一次最多 MERGE_POLL_MINUTES 分钟加余量，必须心跳；工人丢了重试没有副作用（只读）。
 */
export type Profile = 'quick' | 'git' | 'setup' | 'selfCheck' | 'ci' | 'job' | 'segment' | 'poll';

export const ACTIVITY_PROFILE: Readonly<Record<ActivityName, Profile>> = {
  engineStartedAt: 'quick',
  pickRoute: 'quick',
  recordTiming: 'quick',
  saveTaskState: 'quick',
  recordRound: 'quick',
  raiseAlert: 'quick',
  removeWorktree: 'git',
  pushBranch: 'git',
  openPr: 'git',
  updatePrBody: 'git',
  syncMainline: 'git',
  closeIssue: 'git',
  acceptanceDuties: 'quick',
  createWorktree: 'setup',
  waitCi: 'ci',
  probeAssignedRoute: 'job',
  releaseReservation: 'quick',
  readTaskBrief: 'git',
  readMergedTask: 'git',
  runSegment: 'segment',
  readDelivery: 'git',
  coldVerify: 'segment',
  checkGuarded: 'git',
  armAutoMerge: 'git',
  waitMerged: 'poll',
  readCiPolicy: 'quick',
  readCiReviews: 'git',
  mergeNow: 'git',
  planSegmentResume: 'quick',
  segmentSettled: 'quick',
  selfCheck: 'selfCheck',
  taskSpend: 'quick',
  noteBare401: 'quick',
  decideFlowMode: 'git',
};

/** quick 一档一次尝试的限时。 */
const QUICK_TIMEOUT_SECONDS = 30;

/** 重试也治不好的错误码：直接交给失败分流。 */
export const NON_RETRYABLE_CODES: readonly string[] = [
  'AUTH_REQUIRED',
  'PERMISSION_DENIED',
  'WORKFLOWS_PERMISSION',
  'INVALID_INPUT',
];

function retry(maximumAttempts: number, initialInterval: string, maximumInterval: string): RetryPolicy {
  return {
    maximumAttempts,
    initialInterval,
    maximumInterval,
    backoffCoefficient: 2,
    nonRetryableErrorTypes: [...NON_RETRYABLE_CODES],
  };
}

export function profileOptions(profile: Profile, limits: Limits): ActivityOptions {
  const heartbeatTimeout = `${limits.heartbeatSeconds} seconds`;
  switch (profile) {
    case 'quick':
      return {
        startToCloseTimeout: `${QUICK_TIMEOUT_SECONDS} seconds`,
        retry: retry(5, '1 second', '30 seconds'),
      };
    case 'git':
      return { startToCloseTimeout: '5 minutes', retry: retry(3, '5 seconds', '1 minute') };
    case 'setup':
      // 建树 + 装依赖。自测不在这档：它的预算比 20 分钟长，见 selfCheck。
      return {
        startToCloseTimeout: '20 minutes',
        heartbeatTimeout,
        retry: retry(3, '5 seconds', '1 minute'),
      };
    case 'selfCheck':
      // 不和建树同档。建树 20 分钟、重试 3 次；自测预算是测试加 tsc，还要排队等机器名额。
      // 挂在 setup 上时限时先到，整段被判超时后从头再跑，三次都白等。这里限时是三项相加，必须心跳；
      // 只试一次：限时到了交给工作流记 skipped，不再重跑。
      return {
        startToCloseTimeout: `${SELF_CHECK_ACTIVITY_MS / 1000} seconds`,
        heartbeatTimeout,
        retry: retry(1, '1 second', '1 second'),
      };
    case 'ci':
      return {
        startToCloseTimeout: `${limits.ciMinutes} minutes`,
        heartbeatTimeout,
        retry: retry(3, '5 seconds', '1 minute'),
      };
    case 'job':
      return { startToCloseTimeout: '10 minutes', retry: retry(1, '1 second', '1 second') };
    case 'segment':
      return {
        startToCloseTimeout: `${SEGMENT_MINUTES + 15} minutes`,
        heartbeatTimeout,
        retry: retry(1, '1 second', '1 second'),
      };
    case 'poll':
      return {
        startToCloseTimeout: `${MERGE_POLL_MINUTES + 5} minutes`,
        heartbeatTimeout,
        retry: retry(3, '5 seconds', '1 minute'),
      };
  }
}

/** 一个活动的完整选项：它那一档的超时、心跳、重试。 */
export function activityOptions(name: ActivityName, limits: Limits): ActivityOptions {
  return profileOptions(ACTIVITY_PROFILE[name], limits);
}

/**
 * 受剩余期限约束的那一次（挂合并时等检查，workflows/task-merge.ts）：这一档的选项，外加 scheduleToClose＝剩下的秒数，
 * 排队、每次尝试、尝试之间的退避合在一起不越过它；单次尝试的限时也不超过它。重试几次、哪些码不重试照这一档。
 */
export function activityOptionsWithin(name: ActivityName, limits: Limits, seconds: number): ActivityOptions {
  const own = activityOptions(name, limits);
  const attemptMs =
    own.startToCloseTimeout === undefined
      ? seconds * 1000
      : Math.min(msToNumber(own.startToCloseTimeout), seconds * 1000);
  return { ...own, startToCloseTimeout: attemptMs, scheduleToCloseTimeout: seconds * 1000 };
}
