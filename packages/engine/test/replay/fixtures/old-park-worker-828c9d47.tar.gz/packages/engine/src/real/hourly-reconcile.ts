// 每小时对账的真装配：工作树按目录真列（根和仓这两级归 root、755，引擎自己读得了）、属主和删经 fleet-agent-scope
// （real/worktrees.ts）、树里还剩什么以会话用户的身份看（real/user-git.ts 的 treeLeftovers：仓里跑 git，不是仓的用 find
// 一层层列）；需求、子任务、PR 头、批准、受管的仓、合了的 PR 和会话记账从库里读；合了的 PR 问传进来的
// GitHub（auditMergedPrs，和对账补漏同一个）；工作流在不在跑、挂没挂着问这次活动的 Temporal 客户端；这个
// 阶段派不派得出去问选路（store-ports 的 pickRoute：和任务挂起时用的同一套）；GitHub 两个机器人的权限自检问
// @fleet-dao/github 的 selfCheck（受管的仓从库里的 repos 表列）；提醒的读写、操作记录、结局记账是同一个库。

import { lstat, readdir } from 'node:fs/promises';
import { join } from 'node:path';
import { LOCAL_LABEL, parsePrerequisites } from '@fleet-dao/conventions';
import {
  activeLocalLeaseKeys,
  alertByKey,
  countAlertFilings,
  countOpenRunsForIssue,
  type Db,
  findRepoProfile,
  finishScheduleRun,
  getApproval,
  insertAlertOnce,
  issueWorkFacts,
  lastSessionByTree,
  latestAlertByPrefix,
  listManagedRepos,
  listOpenAlerts,
  listOpenTaskRows,
  mergedPrLedgers,
  noteClosedIssueDelivery,
  openAlertsByPrefix,
  openSessionTrees,
  pendingClosedIssueDeliveries,
  prHeadsOfBranch,
  pullMergedAt,
  readPoolHoldsSetting,
  recordAlertFiling,
  recordWorktreeCleanupDone,
  recordWorktreeCleanupStart,
  resolveAlertWithReason,
  saveWorktreeInventory,
  settleQueuedDecision,
  startScheduleRun,
  stopTaskRows,
  subtaskTreeRefs,
  taskContext,
  taskStateOf,
  updateOpenAlert,
  upsertAlert,
  worktreeAuditRows,
  writeLocalOrphans,
} from '@fleet-dao/db';
import { type GitHub, type RepoRef, readCi, readPull, requiredChecksFor } from '@fleet-dao/github';
import { parseRepoProfile } from '@fleet-dao/shared';
import {
  parseTaskWorkflowId,
  requirementWorkflowId,
  subtaskWorkflowId,
} from '@fleet-dao/shared/workflow-ids';
import { deployFacts, handlingOf, pgAlertWork, readDeployLagInput } from '@fleet-dao/store';
import { type Client, WorkflowNotFoundError } from '@temporalio/client';
import { WORKFLOW_TYPES } from '../contract.ts';
import { alertRepoFromText } from '../jobs/alert-sweep.ts';
import type { AutoMergeGitHub } from '../jobs/auto-merge-check.ts';
import type { ClosedIssueEventDeps } from '../jobs/closed-issue-events.ts';
import { CLOSED_ISSUE_ABANDON_BY } from '../jobs/closed-issue-tasks.ts';
import type { GitHubAppCheckDeps } from '../jobs/github-app-check.ts';
import type { HourlyReconcileJobDeps } from '../jobs/hourly-reconcile.ts';
import {
  MAIN_CI_VERDICT_KEY,
  MAIN_RECOVERED_KEY_PREFIX,
  MAIN_RED_KEY_PREFIX,
  mainCiVerdictTitle,
  pushMainRed,
  storedMainCiVerdict,
} from '../jobs/main-red-push.ts';
import { mergedTaskCandidateOf } from '../jobs/merged-task-closure.ts';
import { pushOverduePoolHolds } from '../jobs/pool-hold-push.ts';
import type { LocalLabeledIssue } from '../jobs/reconcile-checks.ts';
import {
  beijingDayStart,
  RECONCILE_ACTOR,
  type WorkflowReader,
  type WorkflowView,
} from '../jobs/reconcile-common.ts';
import type { WorktreeCleanupDeps } from '../jobs/worktree-cleanup.ts';
import { confirmDeletionIdle } from '../jobs/worktree-sweep.ts';
import { type PortContext, PortError, type ShotsDelivery } from '../ports.ts';
import type { CarpoolRegistryView } from '../routing/index.ts';
import { standardPathsList } from '../standard-paths-list.ts';
import {
  type ClosedIssueHoldToken,
  taskCloseClosedIssueUpdate,
  taskSettleMergedUpdate,
  taskStatusQuery,
} from '../task-contract.ts';
import type { ProcLook } from './complex-preserve.ts';
import type { UserExec } from './exec.ts';
import { mainCiRuns } from './main-ci-runs.ts';
import { preserveThenRemove } from './preserve-worktree.ts';
import { PROBE_DIR } from './route-probe.ts';
import { isWorkflowGone } from './route-wake.ts';
import type { SessionOrgReader } from './session-org.ts';
import { keepShotsBeforeRemove } from './shots.ts';
import { createStorePorts } from './store-ports.ts';
import { treeBytes, treeLeftovers } from './user-git.ts';
import { SESSION_TMP_DIR, type WorkTrees } from './worktrees.ts';

/** 引擎镜像裸仓的根：和 github 包（github.ts 的 mirrorRoot）、cold-verify-run.ts 同一条路。 */
export function defaultMirrorRoot(env: NodeJS.ProcessEnv = process.env): string {
  return join(env.FLEET_GITHUB_STATE_DIR?.trim() || '/var/lib/fleet-dao/github', 'mirrors');
}

/**
 * 一个仓的镜像裸仓多大（字节，按占用的块算，和 du 一样；硬链接只算一次，不跟符号链接）。引擎自己的目录，不用借会话用户。
 * 还没镜像过（目录不在）回 null；读不了照抛（没量成）。路径和 github 包的 mirrorPath 一样（owner、仓名都转小写）。
 */
export async function mirrorBytes(
  root: string,
  repo: { owner: string; name: string },
): Promise<number | null> {
  const top = join(root, repo.owner.toLowerCase(), `${repo.name.toLowerCase()}.git`);
  try {
    await lstat(top);
  } catch (err) {
    if ((err as { code?: unknown }).code === 'ENOENT') return null;
    throw err;
  }
  const seen = new Set<string>();
  let bytes = 0;
  const stack = [top];
  while (stack.length > 0) {
    const dir = stack.pop() as string;
    for (const e of await readdir(dir, { withFileTypes: true })) {
      const p = join(dir, e.name);
      const st = await lstat(p);
      const key = `${st.dev}:${st.ino}`;
      if (seen.has(key)) continue;
      seen.add(key);
      bytes += st.blocks * 512;
      if (e.isDirectory()) stack.push(p);
    }
  }
  return bytes;
}

/** 列一个目录：只认目录（符号链接不跟，算「不是目录」，没碰）。读不了照抛。 */
export async function listDirEntries(dir: string): Promise<{ name: string; isDir: boolean }[]> {
  const entries = await readdir(dir, { withFileTypes: true });
  return entries.map((e) => ({ name: e.name, isDir: e.isDirectory() }));
}

const asRecord = (x: unknown): Record<string, unknown> | null =>
  x && typeof x === 'object' ? (x as Record<string, unknown>) : null;

/** status 查询回的东西（需求、子任务都有 parked、waiting、doing；子任务还有 approval）→ 要用的几样。认不出照抛，不当成「没挂着」。 */
export function workflowViewOf(raw: unknown, workflowId: string): WorkflowView {
  const r = asRecord(raw);
  if (!r || typeof r.parked !== 'boolean') {
    throw new Error(`${workflowId} 的 status 查询回的东西认不出（没有 parked）`);
  }
  let waiting: WorkflowView['waiting'] = null;
  if (r.waiting !== null && r.waiting !== undefined) {
    const w = asRecord(r.waiting);
    if (!w || typeof w.kind !== 'string' || typeof w.detail !== 'string' || typeof w.since !== 'string') {
      throw new Error(`${workflowId} 的 status 查询里 waiting 认不出`);
    }
    waiting = { kind: w.kind, detail: w.detail, since: w.since };
  }
  let approval: WorkflowView['approval'] = null;
  if (r.approval !== null && r.approval !== undefined) {
    const a = asRecord(r.approval);
    if (!a || typeof a.approvalId !== 'string' || typeof a.state !== 'string') {
      throw new Error(`${workflowId} 的 status 查询里 approval 认不出`);
    }
    approval = { approvalId: a.approvalId, state: a.state };
  }
  return { parked: r.parked, waiting, doing: typeof r.doing === 'string' ? r.doing : '', approval };
}

/**
 * 任务工作流的 taskStatus 查询（task-contract.ts 的 TaskStatus）→ 对账要用的几样：停着等人（phase = parked）、在等什么、
 * 在做什么。任务工作流没有「等批准」这一项（approval 恒为 null）。认不出照抛，不当成「没挂着」：对账读错查询名、或工作流
 * 回的东西变了形，都该报「没查成」，不能悄悄当成「已经不挂着了」把提醒撤掉（#901）。
 */
export function taskViewOf(raw: unknown, workflowId: string): WorkflowView {
  const r = asRecord(raw);
  if (!r || typeof r.phase !== 'string') {
    throw new Error(`${workflowId} 的 taskStatus 查询回的东西认不出（没有 phase）`);
  }
  let waiting: WorkflowView['waiting'] = null;
  if (r.waiting !== null && r.waiting !== undefined) {
    const w = asRecord(r.waiting);
    if (!w || typeof w.kind !== 'string' || typeof w.detail !== 'string' || typeof w.since !== 'string') {
      throw new Error(`${workflowId} 的 taskStatus 查询里 waiting 认不出`);
    }
    waiting = { kind: w.kind, detail: w.detail, since: w.since };
  }
  return {
    parked: r.phase === 'parked',
    waiting,
    doing: typeof r.doing === 'string' ? r.doing : '',
    approval: null,
  };
}

/**
 * 关单收尾专用（#3002）：停着等人（phase=parked），或已在检查点软暂停（phase=paused 且 waiting.kind=paused）。
 * 别的阶段都是还在跑，包括暂停了但等待还不是 paused、以及别的阶段碰巧 waiting.kind=paused。
 * taskViewOf.parked 仍只认 phase=parked，对账别的读法不跟着放宽。认不出照抛，不当成还在跑。
 */
export function closedIssueHoldOf(raw: unknown, workflowId: string): 'parked' | 'paused-checkpoint' | 'busy' {
  const view = taskViewOf(raw, workflowId);
  if (view.parked) return 'parked';
  if (asRecord(raw)?.phase === 'paused' && view.waiting?.kind === 'paused') return 'paused-checkpoint';
  return 'busy';
}

/** 问 Temporal：没有这条工作流是 missing；别的查不了（连不上、没权限）照抛。 */
export function temporalWorkflows(client: Pick<Client, 'workflow'>): WorkflowReader {
  return {
    async state(workflowId) {
      try {
        const d = await client.workflow.getHandle(workflowId).describe();
        return d.status.name === 'RUNNING'
          ? { state: 'running' }
          : { state: 'closed', status: d.status.name };
      } catch (err) {
        if (err instanceof WorkflowNotFoundError) return { state: 'missing' };
        throw err;
      }
    },
    async view(workflowId) {
      const handle = client.workflow.getHandle(workflowId);
      // 任务工作流（task:）答的是 taskStatus，旧的需求、子任务工作流答的是 status：按编号前缀选，别拿 status 去问任务工作流
      if (workflowId.startsWith('task:')) return taskViewOf(await handle.query(taskStatusQuery), workflowId);
      return workflowViewOf(await handle.query('status'), workflowId);
    },
  };
}

/** 选路这一下不在活动里、不心跳，给一个不会被叫停的上下文。 */
const NO_CTX: PortContext = {
  signal: new AbortController().signal,
  heartbeat() {},
  attempt: 1,
  lastHeartbeat: undefined,
};

/**
 * 自动合并兜底那部分要的 GitHub：这里只声明它要的形状，真装配在 hourlyReconcileJob 里把
 * createGitHub 拿到的那个 GitHub 接进来。
 */
export interface AutoMergeWiringGitHub {
  claims: GitHub['claims'];
  pullFiles: GitHub['pullFiles'];
  readRepoFile: GitHub['readRepoFile'];
  deps: GitHub['deps'];
  /** 不强制 CI 的任务分支由对账直接合并。测试装配不给真合并时，默认实现仍要这个方法在类型上。 */
  mergePr: GitHub['mergePr'];
  /** 主线上读的改标准路径清单文件名；默认 packages/conventions/standard-paths.json（#242）。*/
  standardPathsFile?: string;
}
/** 默认的改标准路径清单（自动合并兜底按这份判 #242）。 */
export const STANDARD_PATHS_FILE = 'packages/conventions/standard-paths.json';

export interface HourlyReconcileWiring {
  db: Db;
  /** 和对账补漏同一个：审最近合了的 PR（镜像、合并人、合并记录）；补拉经接活那道门时现读挂在哪个版本；自动合并兜底用它列 PR、读文件、挂自动合并。 */
  gh: Pick<GitHub, 'auditMergedPrs' | 'readIssueState' | 'openIssue'> &
    Partial<
      Pick<GitHub, 'readGroomFacts' | 'readIssueLabelEvents' | 'readIssueComments' | 'readIssueStates'>
    > &
    AutoMergeWiringGitHub;
  trees: WorkTrees;
  exec: UserExec;
  /** 和收树同一个归档目录（<FLEET_STATE_DIR>/archive）：清扫删树前把界面验收图片存进这里的受限归档（#2983）。 */
  archiveDir: string;
  /** 会话用户此刻挂的组织（real/session-org.ts）：判阶段派不派得出去和选路同一套，也要它。 */
  sessionOrg: SessionOrgReader;
  /** 拼车并发登记的现核（real/carpool-cap.ts，#896）：判阶段派不派得出去和选路同一套，拼车池核对不上也不算派得出去。必填，漏接过不了类型检查。 */
  carpoolRegistry: () => Promise<CarpoolRegistryView>;
  /** 这台机器给人看的名字（FLEET_MACHINE_NAME）。 */
  machine: string;
  /** GitHub 两个机器人在这些仓上的权限够不够（生产是 createGitHub 的 selfCheck）。 */
  selfCheck: GitHubAppCheckDeps['apps']['selfCheck'];
  now?: () => Date;
  log?: HourlyReconcileJobDeps['log'];
  /** 引擎镜像裸仓的根（<FLEET_GITHUB_STATE_DIR>/mirrors）；不给照环境变量拼，和 github 包的 mirrorPath 同一个。 */
  mirrorRoot?: string;
  /** 以下测试用。 */
  gitBin?: string;
  shBin?: string;
  /** 看进程 cwd 的口子；不给用 /proc。 */
  treeProcessLook?: ProcLook;
  listDir?: HourlyReconcileJobDeps['listDir'];
  stageRoutable?: HourlyReconcileJobDeps['stageRoutable'];
  /** 测试用：不给就用选路同一份事实的只读判法（store.stageAllOpen）。 */
  stageAllOpen?: HourlyReconcileJobDeps['stageAllOpen'];
  workflows?: WorkflowReader;
  inspectMax?: number;
  /** 测试用：换掉自动合并兜底那部分的 GitHub / 提醒；不给就照 wiring 的 gh 装。 */
  autoMergeGh?: AutoMergeGitHub;
  autoMergeAlerts?: HourlyReconcileJobDeps['autoMergeAlerts'];
  /** 测试用：换掉「单已关就撤任务」那部分的 Temporal / GitHub 口子；不给就用真的（问 Temporal 在跑的任务工作流、现读单状态）。 */
  closedIssueTasks?: HourlyReconcileJobDeps['closedIssueTasks'];
  mergedTasks?: NonNullable<HourlyReconcileJobDeps['mergedTasks']>;
}

/** 等工作流消费回执的 RPC 上限；到点不代表 Update 未执行，保留未核实，重试同一 updateId。 */
const CLOSED_ISSUE_UPDATE_TIMEOUT_MS = 5_000;

/**
 * 撤掉这个任务工作流还开着的挂起提醒（task:…:park:N）：标已处理，同一事务写操作记录（reason = why）。
 * 对账「单已关且停下等人」那一支用（#1816）；by 默认 engine:hourly-reconcile。
 */
export async function resolveClosedIssueParkAlerts(
  db: Db,
  workflowId: string,
  why: string,
  opts: { by?: string; at?: Date } = {},
): Promise<number> {
  const by = opts.by ?? CLOSED_ISSUE_ABANDON_BY;
  const at = opts.at ?? new Date();
  let n = 0;
  for (const row of await openAlertsByPrefix(db, `${workflowId}:park:`)) {
    const done = await resolveAlertWithReason(db, {
      dedupeKey: row.dedupeKey,
      by,
      why,
      at,
    });
    if (done === 'ok') n += 1;
  }
  return n;
}

/**
 * 「单已关就撤任务」的真口子（#1816 / #3002）：在跑的问 Temporal。
 * isParked 仍只认 phase=parked（别的读法不放宽）。关单收尾问 holdForClose：parked，或检查点软暂停再数开着的会话。
 * 单状态现读，Update 绑精确 run 与停法凭据，只有 accepted 回执才撤挂起提醒。
 */
export function temporalClosedIssueTasks(
  client: Pick<Client, 'workflow' | 'connection'>,
  gh: Pick<GitHub, 'readIssueState'> & Partial<Pick<GitHub, 'readGroomFacts'>>,
  db: Db,
  now: () => Date,
): HourlyReconcileJobDeps['closedIssueTasks'] {
  const { readGroomFacts } = gh;
  return {
    async runningTaskWorkflowIds() {
      const ids: string[] = [];
      for await (const info of client.workflow.list({
        query: `WorkflowType = '${WORKFLOW_TYPES.task}' AND ExecutionStatus = 'Running'`,
      })) {
        ids.push(info.workflowId);
      }
      return ids;
    },
    async isParked(workflowId) {
      const handle = client.workflow.getHandle(workflowId);
      return taskViewOf(await handle.query(taskStatusQuery), workflowId).parked;
    },
    async holdForClose(workflowId) {
      const handle = client.workflow.getHandle(workflowId);
      const raw = await handle.query(taskStatusQuery);
      const kind = closedIssueHoldOf(raw, workflowId);
      if (kind === 'busy') return { kind: 'busy' };
      const capability = asRecord(asRecord(raw)?.closedIssueClose);
      if (capability?.version !== 1)
        throw new Error(`${workflowId} 没有受支持的关单收尾能力，不发无条件放弃`);
      if (capability.token === null) return { kind: 'busy' };
      const token = capability.token as ClosedIssueHoldToken | undefined;
      if (
        token?.version !== 1 ||
        typeof token.runId !== 'string' ||
        !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(token.runId) ||
        token.kind !== (kind === 'parked' ? 'parked' : 'paused') ||
        !Number.isSafeInteger(token.generation) ||
        token.generation < 1 ||
        !Number.isSafeInteger(token.continued) ||
        token.continued < 0
      ) {
        throw new Error(`${workflowId} 关单停法凭据认不出，不动`);
      }
      if (kind === 'parked') return { kind: 'parked', token };
      const ref = parseTaskWorkflowId(workflowId);
      if (!ref) throw new Error(`${workflowId} 认不出是哪张单，开着的会话数没查成`);
      const openSessions = await countOpenRunsForIssue(db, ref.repo, ref.issueNumber, workflowId);
      return { kind: 'paused', openSessions, token };
    },
    resolveParkAlerts: (workflowId, why, by) =>
      resolveClosedIssueParkAlerts(db, workflowId, why, { at: now(), ...(by ? { by } : {}) }),
    openTaskRows: () => listOpenTaskRows(db),
    stopRows: (taskIds, reason) => stopTaskRows(db, taskIds, reason),
    async issueState(repo, issueNumber) {
      return (await gh.readIssueState({ repo, issueNumber })).state;
    },
    ...(readGroomFacts && {
      async openIssueLabels(repo: RepoRef) {
        const facts = await readGroomFacts.call(gh, { repo });
        return new Map(facts.issues.map((i) => [i.number, i.labels] as const));
      },
    }),
    async abandon(workflowId, command, token) {
      if (!token) throw new Error(`${workflowId} 缺少关单停法凭据，不发无条件放弃`);
      try {
        const result = await client.connection.withDeadline(Date.now() + CLOSED_ISSUE_UPDATE_TIMEOUT_MS, () =>
          client.workflow.getHandle(workflowId, token.runId).executeUpdate(taskCloseClosedIssueUpdate, {
            args: [{ token, command }],
            updateId: `closed-issue:${token.runId}:${token.kind}:${token.generation}:${token.continued}`,
          }),
        );
        if (result !== 'accepted' && result !== 'stale' && result !== 'busy')
          throw new Error('关单收尾消费回执认不出');
        return result;
      } catch (err) {
        if (isWorkflowGone(err)) return 'gone';
        throw err;
      }
    },
  };
}

/** 只提交精确合并回执；受理 Update 不代表 finish 已完成，也不提前撤提醒。 */
export function temporalMergedTasks(
  client: Pick<Client, 'workflow' | 'connection'>,
  gh: Pick<GitHub, 'deps'>,
  db: Db,
): NonNullable<HourlyReconcileJobDeps['mergedTasks']> {
  return {
    async workflows() {
      const ids: string[] = [];
      for await (const info of client.workflow.list({
        query: `WorkflowType = '${WORKFLOW_TYPES.task}' AND ExecutionStatus = 'Running'`,
      }))
        ids.push(info.workflowId);
      return ids;
    },
    async candidate(workflowId) {
      const candidate = mergedTaskCandidateOf(
        await client.workflow.getHandle(workflowId).query(taskStatusQuery),
        workflowId,
      );
      if (!candidate) return null;
      const ref = parseTaskWorkflowId(workflowId);
      if (!ref) throw new Error('已合任务工作流身份认不出');
      const count = await countOpenRunsForIssue(db, ref.repo, ref.issueNumber, workflowId);
      if (!Number.isSafeInteger(count) || count < 0) throw new Error('已合任务活动会话数没查成');
      return count === 0 ? candidate : null;
    },
    async readMerged(candidate) {
      const pr = await readPull(gh.deps, candidate.repo, candidate.prNumber, 'engine');
      if (
        pr.number !== candidate.prNumber ||
        pr.base.repo.full_name.toLowerCase() !==
          `${candidate.repo.owner}/${candidate.repo.name}`.toLowerCase()
      )
        throw new Error('已合 PR 仓或编号不符');
      if (pr.merged === undefined && pr.merged_at === undefined)
        throw new Error('PR 合并状态未知，不提交收尾');
      if ((pr.merged === false && pr.merged_at != null) || (pr.merged === true && pr.merged_at === null))
        throw new Error('PR 合并状态矛盾，不提交收尾');
      if (!(pr.merged ?? (pr.merged_at !== null && pr.merged_at !== undefined))) return null;
      if (
        pr.head.sha !== candidate.head ||
        typeof pr.merge_commit_sha !== 'string' ||
        !/^[0-9a-f]{40}$/.test(pr.merge_commit_sha)
      )
        throw new Error('已合 PR 头或真实合并提交不符');
      return {
        repo: candidate.repo,
        prNumber: candidate.prNumber,
        head: candidate.head,
        mergeCommit: pr.merge_commit_sha,
      };
    },
    async settle(candidate, receipt) {
      const { token, workflowId } = candidate;
      try {
        const result = await client.connection.withDeadline(Date.now() + CLOSED_ISSUE_UPDATE_TIMEOUT_MS, () =>
          client.workflow.getHandle(workflowId, token.runId).executeUpdate(taskSettleMergedUpdate, {
            args: [{ token, receipt }],
            updateId: `merged-task:${token.runId}:${token.kind}:${token.generation}:${token.continued}:${receipt.prNumber}:${receipt.head}:${receipt.mergeCommit}`,
          }),
        );
        if (result !== 'accepted' && result !== 'stale' && result !== 'busy')
          throw new Error('已合任务收尾回执认不出');
        return result;
      } catch (error) {
        if (isWorkflowGone(error)) return 'gone';
        throw error;
      }
    },
  };
}

/**
 * 四个 GitHub 读法都在才核「本机做」没人领：开着单的正文/标签、标签时间线和评论，以及前置单状态。
 * 前置号（issue 或 PR）按仓去重，交给 readIssueStates 一批读；合了、关了都算 closed。
 * 缺号、认不出的状态在这里抛，这一轮没读成，上一份名单留着。
 * 测试装配的假 GitHub 往往没有这些，这时一个都不接，
 * 对账那一轮跳过，不记没查成。
 */
function localOrphanWiring(
  w: HourlyReconcileWiring,
  now: () => Date,
): Pick<HourlyReconcileJobDeps, 'localLabeled' | 'activeLeases' | 'saveLocalOrphans'> {
  const { readGroomFacts, readIssueLabelEvents, readIssueComments, readIssueStates } = w.gh;
  if (!readGroomFacts || !readIssueLabelEvents || !readIssueComments || !readIssueStates) return {};
  const gh = w.gh;
  return {
    async localLabeled() {
      const out: LocalLabeledIssue[] = [];
      for (const repo of await listManagedRepos(w.db)) {
        const ref = { owner: repo.owner, name: repo.name };
        const facts = await readGroomFacts.call(gh, { repo: ref });
        const localIssues = facts.issues.filter((issue) => issue.labels.includes(LOCAL_LABEL));
        const prerequisiteNumbers = [
          ...new Set(localIssues.flatMap((issue) => parsePrerequisites(issue.body).issues)),
        ];
        const states = await readIssueStates.call(gh, { repo: ref, numbers: prerequisiteNumbers });
        const prerequisiteStates = new Map<number, 'open' | 'closed'>();
        for (const issueNumber of prerequisiteNumbers) {
          if (!states.has(issueNumber)) {
            throw new Error(`${repo.owner}/${repo.name}#${issueNumber} 的状态缺号`);
          }
          const state = states.get(issueNumber);
          if (state !== 'open' && state !== 'closed') {
            throw new Error(`${repo.owner}/${repo.name}#${issueNumber} 的状态认不出：${String(state)}`);
          }
          prerequisiteStates.set(issueNumber, state);
        }
        for (const issue of localIssues) {
          const [events, comments] = await Promise.all([
            readIssueLabelEvents.call(gh, { repo: ref, issueNumber: issue.number }),
            readIssueComments.call(gh, { repo: ref, issueNumber: issue.number }),
          ]);
          out.push({
            repo: ref,
            issue: issue.number,
            body: issue.body,
            labels: issue.labels,
            prerequisiteStates,
            events,
            comments,
          });
        }
      }
      return out;
    },
    activeLeases: () => activeLocalLeaseKeys(w.db, now()),
    saveLocalOrphans: (items) => writeLocalOrphans(w.db, items, RECONCILE_ACTOR),
  };
}

/** 给 EngineJobs.hourlyReconcile 用的工厂。 */
export function hourlyReconcileJob(
  w: HourlyReconcileWiring,
): (client: Client, taskQueue: string) => HourlyReconcileJobDeps {
  const now = w.now ?? (() => new Date());
  const log: HourlyReconcileJobDeps['log'] =
    w.log ?? ((level, text, fields) => console[level === 'info' ? 'info' : level](text, fields ?? {}));
  const store = createStorePorts({
    db: w.db,
    now,
    sessionOrg: w.sessionOrg,
    carpoolRegistry: w.carpoolRegistry,
  });
  // 和点「继续」以后选路会怎么选是同一套：全熔断时它放一条去试探，也算派得出去。这时它还会顺手把「全熔断」那条提醒
  // 再报一次（条件确实还在）。这条提醒撤不撤不在这里判，走下面的 stageAllOpen（只读，不写库、不报警）。
  const stageRoutable: HourlyReconcileJobDeps['stageRoutable'] =
    w.stageRoutable ??
    (async (stage, taskId) => {
      const r = await store.pickRoute(
        { stage, taskId: taskId ?? '', avoidRouteIds: [], avoidPoolIds: [], avoidModelIds: [] },
        NO_CTX,
      );
      if (r.ok) return { kind: 'dispatch' };
      return r.waitFor === 'none' ? { kind: 'none', detail: r.detail } : { kind: 'wait', detail: r.detail };
    });
  const stageAllOpen: HourlyReconcileJobDeps['stageAllOpen'] =
    w.stageAllOpen ?? ((stage) => store.stageAllOpen(stage));
  // 受管的仓：两处核对里审合并的 PR、机器人权限自检都按这一份（库里的 repos 表）
  const managedRepos = async () =>
    (await listManagedRepos(w.db)).map((r) => ({ owner: r.owner, name: r.name, ciPolicy: r.ciPolicy }));
  // 谁在处理（24 小时再推不给有人在处理、静默了的推）：和驾驶舱同一个口子、同一份判法（原来还有提醒派单，#445 删掉了）
  const alertWork = pgAlertWork(w.db, () => deployFacts(readDeployLagInput()));
  const handling: HourlyReconcileJobDeps['handling'] = async (ids) => {
    const r = await handlingOf(alertWork, ids);
    if (!r.ok) throw new Error(r.why);
    return new Map([...r.byId].map(([id, h]) => [id, { stage: h.stage, line: h.line }]));
  };
  // 立案（#1406）：没人处理超过 24 小时的卡住报警开一张未排期的缺陷单。仓优先用提醒挂着的任务的仓，
  // 没有任务再从键和链接里认；认不出不猜。单状态的关单时刻 GitHub 这个口子不给，关了先记看见的时刻。
  const filing: HourlyReconcileJobDeps['filing'] = {
    async repoOf(alert) {
      if (alert.taskId) {
        const ctx = await taskContext(w.db, alert.taskId);
        if (ctx) return { owner: ctx.repo.owner, name: ctx.repo.name };
      }
      return alertRepoFromText(alert.dedupeKey, alert.link);
    },
    filedToday: (repo) => countAlertFilings(w.db, `${repo.owner}/${repo.name}`, beijingDayStart(now())),
    async issueState(repo, number) {
      const st = await w.gh.readIssueState({ repo, issueNumber: number });
      return { state: st.state, closedAt: null };
    },
    async openIssue(input) {
      const got = await w.gh.openIssue({
        repo: input.repo,
        key: input.key,
        title: input.title,
        body: input.body,
        labels: input.labels,
        milestone: null,
      });
      return { number: got.number };
    },
    recordFiled: (input) =>
      recordAlertFiling(w.db, {
        repo: `${input.repo.owner}/${input.repo.name}`,
        dedupeKey: input.dedupeKey,
        number: input.number,
        actorId: RECONCILE_ACTOR,
        at: now(),
      }),
  };
  // 自动合并兜底（#242）要的 GitHub：列 PR 经 claims.openPulls，把作者是不是机器人、自动合并开没开带过来；
  // 必过检查、CI 判读照和合并闸同一份 readCi / requiredChecksFor；改标准路径的清单读这个仓档案里的文件，
  // 文件不在＝空清单（standardPathsList），认不出照抛。
  const standardPathsOverride = w.gh.standardPathsFile;
  const standardPathsPath = async (repo: RepoRef): Promise<string> => {
    if (standardPathsOverride) return standardPathsOverride;
    const row = await findRepoProfile(w.db, repo.owner, repo.name);
    return parseRepoProfile(row?.profile).standardPathsFile;
  };
  const autoMergeGh: AutoMergeGitHub = w.autoMergeGh ?? {
    async listPrs(repo: RepoRef) {
      const pulls = await w.gh.claims.openPulls(repo);
      return pulls.map((p) => ({
        number: p.number,
        nodeId: p.nodeId,
        state: p.state,
        draft: p.draft,
        authorIsBot: w.gh.claims.isAgentBot(p.author),
        autoMerge: p.autoMerge,
        headSha: p.headSha,
        headRef: p.headRef,
      }));
    },
    pullFiles: (repo: RepoRef, prNumber: number) => w.gh.pullFiles({ repo, prNumber }),
    async checksEvaluate(repo: RepoRef, sha: string, required: string[]) {
      const ci = await readCi(w.gh.deps, repo, sha, required);
      return ci.evaluation.overall;
    },
    requiredChecks: (repo: RepoRef) => requiredChecksFor(w.gh.deps, repo),
    async readStandardPathsFile(repo: RepoRef) {
      const path = await standardPathsPath(repo);
      const r = await w.gh.readRepoFile({ repo, path });
      if (r.file.kind === 'not_file') throw new Error(`读 ${path} 没成（${r.file.why}）`);
      const text = r.file.kind === 'text' ? r.file.text : null;
      // 文件不在＝空清单；认不出在这里抛。原文交给兜底再过同一份函数。
      const recognized = standardPathsList(text);
      return recognized.length === 0 ? null : text;
    },
    enableAutoMerge: (repo: RepoRef, pull) => w.gh.claims.enableAutoMerge(repo, pull),
    async mergeNow(repo: RepoRef, pull: { number: number; expectedHead: string }) {
      const r = await w.gh.mergePr({
        repo,
        prNumber: pull.number,
        expectedHead: pull.expectedHead,
        requireCi: false,
      });
      if (r.merged) return { merged: true };
      return { merged: false, detail: r.detail };
    },
  };
  const autoMergeAlerts: HourlyReconcileJobDeps['autoMergeAlerts'] = w.autoMergeAlerts ?? {
    async raise(x) {
      await upsertAlert(w.db, {
        dedupeKey: x.dedupeKey,
        level: x.level,
        taskId: x.taskId,
        title: x.title,
        body: x.body,
        ...(x.link ? { link: x.link } : {}),
      });
    },
    async resolve(x) {
      return resolveAlertWithReason(w.db, { dedupeKey: x.dedupeKey, by: x.by, why: x.why, at: now() });
    },
    async listOpenByPrefix(prefix) {
      const rows = await listOpenAlerts(w.db, { limit: 500 });
      return rows.alerts.filter((r) => r.dedupeKey.startsWith(prefix));
    },
  };
  return (client) => {
    const preservedShots = new Map<string, ShotsDelivery>();
    return {
      root: w.trees.root,
      gh: autoMergeGh,
      autoMergeAlerts,
      probeDir: PROBE_DIR,
      sessionTmpDir: SESSION_TMP_DIR,
      machine: w.machine,
      listDir: w.listDir ?? listDirEntries,
      pendingCleanup: () => w.trees.pendingCleanup(),
      cleanupNamespace: () => w.trees.cleanupNamespace(),
      treeFor: (repo, branch) => w.trees.treeFor(repo, branch),
      ownerOf: (dir) => w.trees.ownerOf(dir),
      remove: async (dir) => {
        try {
          const user = await w.trees.ownerOf(dir);
          // WorkTrees.ownerOf 仅 ENOENT 回 null；属主未知、权限或读失败均抛错。
          if (!user) return { gone: true };
          const idle = () =>
            confirmDeletionIdle({
              root: w.trees.root,
              dir,
              openSessions: () => openSessionTrees(w.db),
              workflows: w.workflows ?? temporalWorkflows(client),
              issue: (ref) => issueWorkFacts(w.db, ref),
            });
          const answer = await idle();
          if (answer !== 'idle') {
            throw new PortError(
              'WORKTREE_PRESERVED',
              answer === 'busy'
                ? `${dir} 删除前现核仍有任务或会话在用，保留原树`
                : `${dir} 删除前确认不了没人用，保留原树`,
              { retryable: false },
            );
          }
          const result = await preserveThenRemove(
            {
              exec: w.exec,
              user,
              dir,
              scopePrefix: 'reconcile-preserve',
              ...(w.gitBin ? { git: w.gitBin } : {}),
              ...(w.shBin ? { sh: w.shBin } : {}),
            },
            w.archiveDir,
            {
              workRoot: w.trees.root,
              confirmIdle: idle,
              ...(w.treeProcessLook ? { processLook: w.treeProcessLook } : {}),
            },
            preservedShots.get(dir),
            (identity) => w.trees.remove(dir, identity),
          );
          return { gone: result.gone };
        } finally {
          preservedShots.delete(dir);
        }
      },
      // 清扫不看远端（这一路没有镜像）：同一个头记过已交付才认，否则有图就存进受限归档，存不成不删
      keepShots: async (dir, user, at) => {
        const kept = await keepShotsBeforeRemove(
          {
            exec: w.exec,
            user,
            dir,
            scopePrefix: 'reconcile-shots',
            ...(w.gitBin ? { git: w.gitBin } : {}),
            ...(w.shBin ? { sh: w.shBin } : {}),
          },
          {
            archiveDir: w.archiveDir,
            taskId: at.taskId ?? `sweep.${at.rel.replace(/\//g, '.')}`,
            issueNumber: at.issueNumber,
            now: now(),
          },
        );
        if (kept.outcome === 'archived' || kept.outcome === 'delivered') preservedShots.set(dir, kept);
        return kept;
      },
      leftovers: (dir, user, known, scratch) =>
        treeLeftovers(
          {
            exec: w.exec,
            user,
            dir,
            scopePrefix: 'reconcile',
            ...(w.gitBin ? { git: w.gitBin } : {}),
            ...(w.shBin ? { sh: w.shBin } : {}),
          },
          known,
          { scratch },
        ),
      size: (dir, user) =>
        treeBytes({
          exec: w.exec,
          user,
          dir,
          scopePrefix: 'reconcile-du',
          ...(w.shBin ? { sh: w.shBin } : {}),
        }),
      lastSessions: () => lastSessionByTree(w.db),
      mirrorBytes: (repo) => mirrorBytes(w.mirrorRoot ?? defaultMirrorRoot(), repo),
      saveInventory: (inv) => saveWorktreeInventory(w.db, inv),
      issue: (ref) => issueWorkFacts(w.db, ref),
      prHeads: (ref) => prHeadsOfBranch(w.db, ref),
      subtaskTrees: (ids) => subtaskTreeRefs(w.db, ids),
      openSessions: () => openSessionTrees(w.db),
      taskState: (taskId) => taskStateOf(w.db, taskId),
      repos: managedRepos,
      auditMergedPrs: (repo, since) => w.gh.auditMergedPrs(repo, since),
      ledgers: (input) => mergedPrLedgers(w.db, input),
      async approval(id) {
        const a = await getApproval(w.db, id);
        if (!a) return null;
        // 子任务发的等子任务工作流；Fusion 发的（没有子任务）等需求工作流（编号和需求工作流同一个）。这两种工作流引擎里都
        // 已经没有了：旧批准提醒查出来是「不在了」就撤，这里要继续拼旧的 req: 编号才撤得掉，不能换成 task:（任务工作流的
        // status 查询形状不同，对账读不了会一直记没查成）。#901 查出来的，随提醒对账那一整套旧读法另开单换。
        let waitingWorkflowId: string | null = a.subtaskId ? subtaskWorkflowId(a.subtaskId) : null;
        if (!a.subtaskId) {
          const task = await taskContext(w.db, a.taskId);
          waitingWorkflowId = task ? requirementWorkflowId(task.repo, task.issueNumber) : null;
        }
        return { decision: a.decision, decidedBy: a.decidedBy, waitingWorkflowId };
      },
      workflows: w.workflows ?? temporalWorkflows(client),
      closedIssueTasks: w.closedIssueTasks ?? temporalClosedIssueTasks(client, w.gh, w.db, now),
      mergedTasks: w.mergedTasks ?? temporalMergedTasks(client, w.gh, w.db),
      stageRoutable,
      stageAllOpen,
      handling,
      filing,
      // 历史事实类（reconcile:pr、reconcile:ledger）要合并时刻才知道该不该跳过。镜像没写上再问 GitHub；都没有就抛，上面记没查成、不跳过。
      prMergedAt: async (repo, number) => {
        const mirrored = await pullMergedAt(w.db, repo.owner, repo.name, number);
        if (mirrored) return mirrored;
        const pr = await readPull(w.gh.deps, repo, number, 'engine');
        if (!pr.merged_at) throw new Error(`${repo.owner}/${repo.name}#${number} 没有合并时刻`);
        const at = new Date(pr.merged_at);
        if (!Number.isFinite(at.getTime())) {
          throw new Error(`${repo.owner}/${repo.name}#${number} 的合并时刻认不出`);
        }
        return at;
      },
      alerts: {
        listOpen: (limit) => listOpenAlerts(w.db, { limit }),
        byKey: (key) => alertByKey(w.db, key),
        latestByPrefix: (prefix) => latestAlertByPrefix(w.db, prefix),
        resolve: (x) =>
          resolveAlertWithReason(w.db, {
            dedupeKey: x.dedupeKey,
            by: x.by,
            why: x.why,
            at: now(),
            ...(x.auditActor ? { auditActor: x.auditActor } : {}),
          }),
        async raise(x) {
          await upsertAlert(w.db, {
            dedupeKey: x.dedupeKey,
            level: x.level,
            taskId: x.taskId,
            title: x.title,
            body: x.body,
            ...(x.link ? { link: x.link } : {}),
            ...(x.options ? { options: x.options } : {}),
            ...(x.reason ? { reason: x.reason } : {}),
          });
        },
        insertOnce: (x) => insertAlertOnce(w.db, x),
        updateOpen: (x) => updateOpenAlert(w.db, { ...x, at: now() }),
        settleQueued: (x) => settleQueuedDecision(w.db, { ...x, auditActor: RECONCILE_ACTOR, at: now() }),
      },
      apps: {
        repos: managedRepos,
        selfCheck: (repos) => w.selfCheck(repos),
      },
      runs: {
        start: (job, at) => startScheduleRun(w.db, job, at),
        finish: (id, result, at) => finishScheduleRun(w.db, id, result, at),
      },
      ...localOrphanWiring(w, now),
      poolHoldPush: () =>
        pushOverduePoolHolds({
          now,
          readSetting: () => readPoolHoldsSetting(w.db),
          sentBody: async (key) => (await alertByKey(w.db, key))?.body ?? null,
          markSent: async (x) => {
            await upsertAlert(w.db, {
              dedupeKey: x.dedupeKey,
              level: 'daily',
              taskId: null,
              title: x.title,
              body: x.body,
              link: x.link,
            });
          },
          send: handOffToFeishuPush,
        }),
      mainRedPush: () =>
        pushMainRed({
          listPushRuns: mainCiRuns({ client: w.gh.deps.client }),
          previousVerdict: async () => {
            const [stored, red, recovered] = await Promise.all([
              alertByKey(w.db, MAIN_CI_VERDICT_KEY),
              latestAlertByPrefix(w.db, MAIN_RED_KEY_PREFIX),
              latestAlertByPrefix(w.db, MAIN_RECOVERED_KEY_PREFIX),
            ]);
            return storedMainCiVerdict(stored?.body, red, recovered);
          },
          sentBody: async (key) => (await alertByKey(w.db, key))?.body ?? null,
          markSent: async (x) => {
            await upsertAlert(w.db, {
              dedupeKey: x.dedupeKey,
              level: 'daily',
              taskId: null,
              title: x.title,
              body: x.body,
              link: x.link,
            });
            // 主线转绿：开着的主线红都撤掉（自愈了）。飞书推送只推开满 60 分钟还没撤的主线红（packages/db 的 feishu-push.ts），
            // 不撤的话转绿以后它照样会被推出去
            if (x.dedupeKey.startsWith(MAIN_RECOVERED_KEY_PREFIX)) {
              for (const red of await openAlertsByPrefix(w.db, MAIN_RED_KEY_PREFIX)) {
                await resolveAlertWithReason(w.db, {
                  dedupeKey: red.dedupeKey,
                  by: 'engine:main-red-push',
                  why: '主线转绿了',
                  at: now(),
                });
              }
            }
          },
          rememberVerdict: async (x) => {
            await upsertAlert(w.db, {
              dedupeKey: MAIN_CI_VERDICT_KEY,
              level: 'daily',
              taskId: null,
              title: mainCiVerdictTitle(x.verdict),
              body: x.verdict,
              link: x.link,
            });
          },
          send: handOffToFeishuPush,
        }),
      now,
      log,
      ...(w.inspectMax === undefined ? {} : { inspectMax: w.inspectMax }),
    };
  };
}

/**
 * 主线红、整池暂停到期「推飞书」：引擎不自己发（引擎没有飞书凭据，原来的群机器人 webhook 从没人放过、一次都没推成）。
 * markSent 写的那一行提醒（键 feishu:…）就是要推的消息，驾驶舱后端的飞书推送（packages/api 的 feishu-push.ts）照它推进团队群、
 * 记送达；推不出去由看门狗的「飞书推送不通」报。所以这里的「发」只是交出去，不会失败。
 */
const handOffToFeishuPush = async (_text: string): Promise<void> => {};

/**
 * 一键清理没用的工作树（#1993，jobs/worktree-cleanup.ts）：清扫用和每小时对账**同一份**装配（同一个判据、同一个删树口子），
 * 操作记录读写 audit_log（target worktrees），清单存 worktree_inventory。
 */
export function worktreeCleanupJob(
  w: HourlyReconcileWiring,
): (client: Client, taskQueue: string) => WorktreeCleanupDeps {
  const hourly = hourlyReconcileJob(w);
  return (client, taskQueue) => {
    const deps = hourly(client, taskQueue);
    return {
      sweep: () => deps,
      rows: (since) => worktreeAuditRows(w.db, since),
      recordStart: (i) => recordWorktreeCleanupStart(w.db, i),
      recordDone: (i) => recordWorktreeCleanupDone(w.db, i),
      saveInventory: (inv) => saveWorktreeInventory(w.db, inv),
      openAlerts: async () => (await listOpenAlerts(w.db, { limit: 500 })).alerts,
      now: deps.now,
      log: deps.log,
    };
  };
}

/** 单一关就撤停着等人的任务（jobs/closed-issue-events.ts，#2103）：撤的那一套和每小时对账同一份装配（closedIssueTasks）。 */
export function closedIssueEventsJob(
  w: HourlyReconcileWiring,
): (client: Client, taskQueue: string) => ClosedIssueEventDeps {
  const hourly = hourlyReconcileJob(w);
  return (client, taskQueue) => {
    const deps = hourly(client, taskQueue);
    return {
      pending: (since) => pendingClosedIssueDeliveries(w.db, since),
      markHandled: (deliveryId, note) => noteClosedIssueDelivery(w.db, deliveryId, note),
      tasks: () => deps,
      now: deps.now,
      log: deps.log,
    };
  };
}
